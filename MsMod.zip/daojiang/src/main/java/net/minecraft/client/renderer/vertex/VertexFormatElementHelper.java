package net.minecraft.client.renderer.vertex;

import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.client.renderer.OpenGlHelper;
import net.minecraftforge.fml.common.FMLLog;
import net.minecraftforge.fml.relauncher.Side;
import net.minecraftforge.fml.relauncher.SideOnly;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.lwjgl.opengl.DraftGL;
import org.lwjgl.opengl.GL11;
import org.lwjgl.opengl.GL20;

@SideOnly(Side.CLIENT)
public class VertexFormatElementHelper
{
    private static final Logger LOGGER = LogManager.getLogger();
    private final VertexFormatElementHelper.EnumType type;
    private final VertexFormatElementHelper.EnumUsage usage;
    private final int index;
    private final int elementCount;

    public VertexFormatElementHelper(int indexIn, VertexFormatElementHelper.EnumType typeIn, VertexFormatElementHelper.EnumUsage usageIn, int count)
    {
        if (this.isFirstOrUV(indexIn, usageIn))
        {
            this.usage = usageIn;
        }
        else
        {
            LOGGER.warn("Multiple vertex elements of the same type other than UVs are not supported. Forcing type to UV.");
            this.usage = VertexFormatElementHelper.EnumUsage.UV;
        }

        this.type = typeIn;
        this.index = indexIn;
        this.elementCount = count;
    }

    private final boolean isFirstOrUV(int p_177372_1_, VertexFormatElementHelper.EnumUsage p_177372_2_)
    {
        return p_177372_1_ == 0 || p_177372_2_ == VertexFormatElementHelper.EnumUsage.UV;
    }

    public final VertexFormatElementHelper.EnumType getType()
    {
        return this.type;
    }

    public final VertexFormatElementHelper.EnumUsage getUsage()
    {
        return this.usage;
    }

    public final int getElementCount()
    {
        return this.elementCount;
    }

    public final int getIndex()
    {
        return this.index;
    }

    public String toString()
    {
        return this.elementCount + "," + this.usage.getDisplayName() + "," + this.type.getDisplayName();
    }

    public final int getSize()
    {
        return this.type.getSize() * this.elementCount;
    }

    public final boolean isPositionElement()
    {
        return this.usage == VertexFormatElementHelper.EnumUsage.POSITION;
    }

    public boolean equals(Object p_equals_1_)
    {
        if (this == p_equals_1_)
        {
            return true;
        }
        else if (p_equals_1_ != null && this.getClass() == p_equals_1_.getClass())
        {
            VertexFormatElementHelper vertexformatelement = (VertexFormatElementHelper)p_equals_1_;

            if (this.elementCount != vertexformatelement.elementCount)
            {
                return false;
            }
            else if (this.index != vertexformatelement.index)
            {
                return false;
            }
            else if (this.type != vertexformatelement.type)
            {
                return false;
            }
            else
            {
                return this.usage == vertexformatelement.usage;
            }
        }
        else
        {
            return false;
        }
    }

    public int hashCode()
    {
        int i = this.type.hashCode();
        i = 31 * i + this.usage.hashCode();
        i = 31 * i + this.index;
        i = 31 * i + this.elementCount;
        return i;
    }

    @SideOnly(Side.CLIENT)
    public static enum EnumType
    {
        FLOAT(4, "Float", 5126),
        UBYTE(1, "Unsigned Byte", 5121),
        BYTE(1, "Byte", 5120),
        USHORT(2, "Unsigned Short", 5123),
        SHORT(2, "Short", 5122),
        UINT(4, "Unsigned Int", 5125),
        INT(4, "Int", 5124);

        private final int size;
        private final String displayName;
        private final int glConstant;

        private EnumType(int sizeIn, String displayNameIn, int glConstantIn)
        {
            this.size = sizeIn;
            this.displayName = displayNameIn;
            this.glConstant = glConstantIn;
        }

        public int getSize()
        {
            return this.size;
        }

        public String getDisplayName()
        {
            return this.displayName;
        }

        public int getGlConstant()
        {
            return this.glConstant;
        }
    }

    @SideOnly(Side.CLIENT)
    public static enum EnumUsage
    {
        POSITION("Position"),
        NORMAL("Normal"),
        COLOR("Vertex Color"),
        UV("UV"),
        // As of 1.8.8 - unused in vanilla; use GENERIC for now
        @Deprecated
        MATRIX("Bone Matrix"),
        @Deprecated
        BLEND_WEIGHT("Blend Weight"),
        PADDING("Padding"),
        GENERIC("Generic");

        public void preDraw(VertexFormatHelper format, int element, int stride, java.nio.ByteBuffer buffer) {
            VertexFormatElementHelper attr = format.getElement(element);
            int count = attr.getElementCount();
            int constant = attr.getType().getGlConstant();
            buffer.position(format.getOffset(element));
            switch(this)
            {
                case POSITION:
                    DraftGL.glVertexPointer(count, constant, stride, buffer);
                    DraftGL.glEnableClientState(GL11.GL_VERTEX_ARRAY);
                    break;
                case NORMAL:
                    if(count != 3)
                    {
                        throw new IllegalArgumentException("Normal attribute should have the size 3: " + attr);
                    }
                    DraftGL.glNormalPointer(constant, stride, buffer);
                    DraftGL.glEnableClientState(GL11.GL_NORMAL_ARRAY);
                    break;
                case COLOR:
                    DraftGL.glColorPointer(count, constant, stride, buffer);
                    DraftGL.glEnableClientState(GL11.GL_COLOR_ARRAY);
                    break;
                case UV:
                    OpenGlHelper.setClientActiveTexture(OpenGlHelper.defaultTexUnit + attr.getIndex());
                    DraftGL.glTexCoordPointer(count, constant, stride, buffer);
                    DraftGL.glEnableClientState(GL11.GL_TEXTURE_COORD_ARRAY);
                    OpenGlHelper.setClientActiveTexture(OpenGlHelper.defaultTexUnit);
                    break;
                case PADDING:
                    break;
                case GENERIC:
                    DraftGL.glEnableVertexAttribArray(attr.getIndex());
                    DraftGL.glVertexAttribPointer(attr.getIndex(), count, constant, false, stride, buffer);
                    break;
            }
        }
        public void postDraw(VertexFormatHelper format, int element, int stride, java.nio.ByteBuffer buffer) {
            VertexFormatElementHelper attr = format.getElement(element);
            switch(this)
            {
                case POSITION:
                    DraftGL.glDisableClientState(GL11.GL_VERTEX_ARRAY);
                    break;
                case NORMAL:
                    DraftGL.glDisableClientState(GL11.GL_NORMAL_ARRAY);
                    break;
                case COLOR:
                    DraftGL.glDisableClientState(GL11.GL_COLOR_ARRAY);
                    // is this really needed?
                    GlStateManager.resetColor();
                    break;
                case UV:
                    OpenGlHelper.setClientActiveTexture(OpenGlHelper.defaultTexUnit + attr.getIndex());
                    DraftGL.glDisableClientState(GL11.GL_TEXTURE_COORD_ARRAY);
                    OpenGlHelper.setClientActiveTexture(OpenGlHelper.defaultTexUnit);
                    break;
                case PADDING:
                    break;
                case GENERIC:
                    DraftGL.glDisableVertexAttribArray(attr.getIndex());
                    break;
            }
        }

        private final String displayName;

        private EnumUsage(String displayNameIn)
        {
            this.displayName = displayNameIn;
        }

        public String getDisplayName()
        {
            return this.displayName;
        }
    }
}
