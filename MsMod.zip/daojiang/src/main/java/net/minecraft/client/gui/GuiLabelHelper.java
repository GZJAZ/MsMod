package net.minecraft.client.gui;

import com.google.common.collect.Lists;
import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.*;
import net.minecraft.client.renderer.vertex.*;
import net.minecraft.client.resources.I18n;
import net.minecraftforge.fml.relauncher.Side;
import net.minecraftforge.fml.relauncher.SideOnly;
import org.lwjgl.opengl.DraftGL;

import java.nio.ByteBuffer;
import java.util.List;

@SideOnly(Side.CLIENT)
public class GuiLabelHelper extends Gui {
    protected int width = 200;
    protected int height = 20;
    public int x;
    public int y;
    private final List<String> labels;
    public int id;
    private boolean centered;
    public boolean visible = true;
    private boolean labelBgEnabled;
    private final int textColor;
    private int backColor;
    private int ulColor;
    private int brColor;
    private final FontRendererHelper fontRenderer;
    private int border;

    public GuiLabelHelper(FontRendererHelper fontRendererObj, int p_i45540_2_, int p_i45540_3_, int p_i45540_4_, int p_i45540_5_, int p_i45540_6_, int p_i45540_7_)
    {
        this.fontRenderer = fontRendererObj;
        this.id = p_i45540_2_;
        this.x = p_i45540_3_;
        this.y = p_i45540_4_;
        this.width = p_i45540_5_;
        this.height = p_i45540_6_;
        this.labels = Lists.<String>newArrayList();
        this.centered = false;
        this.labelBgEnabled = false;
        this.textColor = p_i45540_7_;
        this.backColor = -1;
        this.ulColor = -1;
        this.brColor = -1;
        this.border = 0;
    }

    public void addLine(String p_175202_1_)
    {
        this.labels.add(I18n.format(p_175202_1_));
    }

    public GuiLabelHelper setCentered()
    {
        this.centered = true;
        return this;
    }

    public void drawLabel(Minecraft mc, int mouseX, int mouseY)
    {
        if (this.visible)
        {
            GlStateManager.enableBlend();
            GlStateManager.tryBlendFuncSeparate(GlStateManager.SourceFactor.SRC_ALPHA, GlStateManager.DestFactor.ONE_MINUS_SRC_ALPHA, GlStateManager.SourceFactor.ONE, GlStateManager.DestFactor.ZERO);
            this.drawLabelBackground(mc, mouseX, mouseY);
            int i = this.y + this.height / 2 + this.border / 2;
            int j = i - this.labels.size() * 10 / 2;

            for (int k = 0; k < this.labels.size(); ++k)
            {
                if (this.centered)
                {
                    drawCenteredString(this.fontRenderer, this.labels.get(k), this.x + this.width / 2, j + k * 10, this.textColor);
                }
                else
                {
                    this.drawString(this.fontRenderer, this.labels.get(k), this.x, j + k * 10, this.textColor);
                }
            }
        }
    }

    public void drawString(FontRendererHelper fontRendererIn, String text, int x, int y, int color)
    {
        fontRendererIn.drawStringWithShadow(text, (float)x, (float)y, color);
    }

    public void drawCenteredString(FontRendererHelper fontRendererIn, String text, int x, int y, int color) {
        fontRendererIn.drawStringWithShadow(text, (float) (x - fontRendererIn.getStringWidth(text) / 2), (float) y, color);
    }

    protected void drawLabelBackground(Minecraft mcIn, int p_146160_2_, int p_146160_3_)
    {
        if (this.labelBgEnabled)
        {
            int i = this.width + this.border * 2;
            int j = this.height + this.border * 2;
            int k = this.x - this.border;
            int l = this.y - this.border;
            int left = k ;
            int top = l;
            int right = k + i;
            int bottom = l + j;
            int color = this.backColor;
            if (left < right) {
                int a = left;
                left = right;
                right = a;
            }
            if (top < bottom) {
                int g = top;
                top = bottom;
                bottom = g;
            }
            float f3 = (float)(color >> 24 & 255) / 255.0F;
            float f = (float)(color >> 16 & 255) / 255.0F;
            float f1 = (float)(color >> 8 & 255) / 255.0F;
            float f2 = (float)(color & 255) / 255.0F;
            TessellatorHelper tessellator = TessellatorHelper.getInstance();
            BufferBuilderHelper bufferbuilder = tessellator.getBuffer();
            GlStateManager.enableBlend();
            GlStateManager.disableTexture2D();
            GlStateManager.tryBlendFuncSeparate(GlStateManager.SourceFactor.SRC_ALPHA, GlStateManager.DestFactor.ONE_MINUS_SRC_ALPHA, GlStateManager.SourceFactor.ONE, GlStateManager.DestFactor.ZERO);
            GlStateManager.color(f, f1, f2, f3);
            bufferbuilder.begin(7, DefaultVertexFormatsHelper.POSITION_TEX_COLOR);
            bufferbuilder.pos((double)left, (double)bottom, 0.0D).endVertex();
            bufferbuilder.pos((double)right, (double)bottom, 0.0D).endVertex();
            bufferbuilder.pos((double)right, (double)top, 0.0D).endVertex();
            bufferbuilder.pos((double)left, (double)top, 0.0D).endVertex();
            bufferbuilder.finishDrawing();
            VertexFormatHelper vertexformat = bufferbuilder.getVertexFormat();
            int z = vertexformat.getNextOffset();
            ByteBuffer bytebuffer = bufferbuilder.getByteBuffer();
            List<VertexFormatElementHelper> list = vertexformat.getElements();
            for (int j1 = 0; j1 < list.size(); ++j1) {
                VertexFormatElementHelper vertexformatelement = list.get(j1);
                VertexFormatElementHelper.EnumUsage vertexformatelement$enumusage = vertexformatelement.getUsage();
                int k1 = vertexformatelement.getType().getGlConstant();
                int l1 = vertexformatelement.getIndex();
                bytebuffer.position(vertexformat.getOffset(j1));

                // moved to VertexFormatElement.preDraw
                vertexformatelement.getUsage().preDraw(vertexformat, j1, z, bytebuffer);
            }
            DraftGL.glDrawArrays(bufferbuilder.getDrawMode(), 0, bufferbuilder.getVertexCount());
            int i1 = 0;
            for (int j1 = list.size(); i1 < j1; ++i1) {
                VertexFormatElementHelper vertexformatelement1 = list.get(i1);
                VertexFormatElementHelper.EnumUsage vertexformatelement$enumusage1 = vertexformatelement1.getUsage();
                int k1 = vertexformatelement1.getIndex();

                // moved to VertexFormatElement.postDraw
                vertexformatelement1.getUsage().postDraw(vertexformat, i1, z, bytebuffer);
            }
            bufferbuilder.reset();
            GlStateManager.enableTexture2D();
            GlStateManager.disableBlend();
            int startX = k;
            int endX = k + i;
            int y = l;

            if (endX < startX)
            {
                int d = startX;
                startX = endX;
                endX = d;
            }
            drawRect(startX, y, endX + 1, y + 1, color);

            this.drawHorizontalLine(k, k + i, l + j, this.brColor);
            int startX1 = k;
            int endX1 = k+i;
            int y1 = l+j;
            if (endX1 < startX1)
            {
                int i2 = startX1;
                startX1 = endX1;
                endX1 = i2;
            }
            drawRect(startX, y, endX + 1, y + 1, color);

            this.drawVerticalLine(k, l, l + j, this.ulColor);
            this.drawVerticalLine(k + i, l, l + j, this.brColor);
        }
    }

    protected void drawVerticalLine(int x, int startY, int endY, int color)
    {
        if (endY < startY)
        {
            int i = startY;
            startY = endY;
            endY = i;
        }

        drawRect(x, startY + 1, x + 1, endY, color);
    }

    public static void drawRect(int left, int top, int right, int bottom, int color)
    {
        if (left < right)
        {
            int i = left;
            left = right;
            right = i;
        }

        if (top < bottom)
        {
            int j = top;
            top = bottom;
            bottom = j;
        }

        float f3 = (float)(color >> 24 & 255) / 255.0F;
        float f = (float)(color >> 16 & 255) / 255.0F;
        float f1 = (float)(color >> 8 & 255) / 255.0F;
        float f2 = (float)(color & 255) / 255.0F;
        TessellatorHelper tessellator = TessellatorHelper.getInstance();
        BufferBuilderHelper bufferbuilder = tessellator.getBuffer();
        GlStateManager.enableBlend();
        GlStateManager.disableTexture2D();
        GlStateManager.tryBlendFuncSeparate(GlStateManager.SourceFactor.SRC_ALPHA, GlStateManager.DestFactor.ONE_MINUS_SRC_ALPHA, GlStateManager.SourceFactor.ONE, GlStateManager.DestFactor.ZERO);
        GlStateManager.color(f, f1, f2, f3);
        bufferbuilder.begin(7, DefaultVertexFormatsHelper.POSITION_TEX_COLOR);
        bufferbuilder.pos((double)left, (double)bottom, 0.0D).endVertex();
        bufferbuilder.pos((double)right, (double)bottom, 0.0D).endVertex();
        bufferbuilder.pos((double)right, (double)top, 0.0D).endVertex();
        bufferbuilder.pos((double)left, (double)top, 0.0D).endVertex();
        bufferbuilder.finishDrawing();
        VertexFormatHelper vertexformat = bufferbuilder.getVertexFormat();
        int z = vertexformat.getNextOffset();
        ByteBuffer bytebuffer = bufferbuilder.getByteBuffer();
        List<VertexFormatElementHelper> list = vertexformat.getElements();
        for (int j1 = 0; j1 < list.size(); ++j1) {
            VertexFormatElementHelper vertexformatelement = list.get(j1);
            VertexFormatElementHelper.EnumUsage vertexformatelement$enumusage = vertexformatelement.getUsage();
            int k1 = vertexformatelement.getType().getGlConstant();
            int l1 = vertexformatelement.getIndex();
            bytebuffer.position(vertexformat.getOffset(j1));

            // moved to VertexFormatElement.preDraw
            vertexformatelement.getUsage().preDraw(vertexformat, j1, z, bytebuffer);
        }
        DraftGL.glDrawArrays(bufferbuilder.getDrawMode(), 0, bufferbuilder.getVertexCount());
        int i1 = 0;
        for (int j1 = list.size(); i1 < j1; ++i1) {
            VertexFormatElementHelper vertexformatelement1 = list.get(i1);
            VertexFormatElementHelper.EnumUsage vertexformatelement$enumusage1 = vertexformatelement1.getUsage();
            int k1 = vertexformatelement1.getIndex();

            // moved to VertexFormatElement.postDraw
            vertexformatelement1.getUsage().postDraw(vertexformat, i1, z, bytebuffer);
        }
        GlStateManager.enableTexture2D();
        GlStateManager.disableBlend();
    }
}
