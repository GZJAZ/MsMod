package net.minecraft.client.renderer.vertex;

import net.minecraftforge.fml.relauncher.Side;
import net.minecraftforge.fml.relauncher.SideOnly;

@SideOnly(Side.CLIENT)
public class DefaultVertexFormatsHelper {
    public static final VertexFormatHelper BLOCK = new VertexFormatHelper();
    public static final VertexFormatHelper ITEM = new VertexFormatHelper();
    public static final VertexFormatHelper OLDMODEL_POSITION_TEX_NORMAL = new VertexFormatHelper();
    public static final VertexFormatHelper PARTICLE_POSITION_TEX_COLOR_LMAP = new VertexFormatHelper();
    public static final VertexFormatHelper POSITION = new VertexFormatHelper();
    public static final VertexFormatHelper POSITION_COLOR = new VertexFormatHelper();
    public static final VertexFormatHelper POSITION_TEX = new VertexFormatHelper();
    public static final VertexFormatHelper POSITION_NORMAL = new VertexFormatHelper();
    public static final VertexFormatHelper POSITION_TEX_COLOR = new VertexFormatHelper();
    public static final VertexFormatHelper POSITION_TEX_NORMAL = new VertexFormatHelper();
    public static final VertexFormatHelper POSITION_TEX_LMAP_COLOR = new VertexFormatHelper();
    public static final VertexFormatHelper POSITION_TEX_COLOR_NORMAL = new VertexFormatHelper();
    public static final VertexFormatElementHelper POSITION_3F = new VertexFormatElementHelper(0, VertexFormatElementHelper.EnumType.FLOAT, VertexFormatElementHelper.EnumUsage.POSITION, 3);
    public static final VertexFormatElementHelper COLOR_4UB = new VertexFormatElementHelper(0, VertexFormatElementHelper.EnumType.UBYTE, VertexFormatElementHelper.EnumUsage.COLOR, 4);
    public static final VertexFormatElementHelper TEX_2F = new VertexFormatElementHelper(0, VertexFormatElementHelper.EnumType.FLOAT, VertexFormatElementHelper.EnumUsage.UV, 2);
    public static final VertexFormatElementHelper TEX_2S = new VertexFormatElementHelper(1, VertexFormatElementHelper.EnumType.SHORT, VertexFormatElementHelper.EnumUsage.UV, 2);
    public static final VertexFormatElementHelper NORMAL_3B = new VertexFormatElementHelper(0, VertexFormatElementHelper.EnumType.BYTE, VertexFormatElementHelper.EnumUsage.NORMAL, 3);
    public static final VertexFormatElementHelper PADDING_1B = new VertexFormatElementHelper(0, VertexFormatElementHelper.EnumType.BYTE, VertexFormatElementHelper.EnumUsage.PADDING, 1);

    static {
        BLOCK.addElement(POSITION_3F);
        BLOCK.addElement(COLOR_4UB);
        BLOCK.addElement(TEX_2F);
        BLOCK.addElement(TEX_2S);
        ITEM.addElement(POSITION_3F);
        ITEM.addElement(COLOR_4UB);
        ITEM.addElement(TEX_2F);
        ITEM.addElement(NORMAL_3B);
        ITEM.addElement(PADDING_1B);
        OLDMODEL_POSITION_TEX_NORMAL.addElement(POSITION_3F);
        OLDMODEL_POSITION_TEX_NORMAL.addElement(TEX_2F);
        OLDMODEL_POSITION_TEX_NORMAL.addElement(NORMAL_3B);
        OLDMODEL_POSITION_TEX_NORMAL.addElement(PADDING_1B);
        PARTICLE_POSITION_TEX_COLOR_LMAP.addElement(POSITION_3F);
        PARTICLE_POSITION_TEX_COLOR_LMAP.addElement(TEX_2F);
        PARTICLE_POSITION_TEX_COLOR_LMAP.addElement(COLOR_4UB);
        PARTICLE_POSITION_TEX_COLOR_LMAP.addElement(TEX_2S);
        POSITION.addElement(POSITION_3F);
        POSITION_COLOR.addElement(POSITION_3F);
        POSITION_COLOR.addElement(COLOR_4UB);
        POSITION_TEX.addElement(POSITION_3F);
        POSITION_TEX.addElement(TEX_2F);
        POSITION_NORMAL.addElement(POSITION_3F);
        POSITION_NORMAL.addElement(NORMAL_3B);
        POSITION_NORMAL.addElement(PADDING_1B);
        POSITION_TEX_COLOR.addElement(POSITION_3F);
        POSITION_TEX_COLOR.addElement(TEX_2F);
        POSITION_TEX_COLOR.addElement(COLOR_4UB);
        POSITION_TEX_NORMAL.addElement(POSITION_3F);
        POSITION_TEX_NORMAL.addElement(TEX_2F);
        POSITION_TEX_NORMAL.addElement(NORMAL_3B);
        POSITION_TEX_NORMAL.addElement(PADDING_1B);
        POSITION_TEX_LMAP_COLOR.addElement(POSITION_3F);
        POSITION_TEX_LMAP_COLOR.addElement(TEX_2F);
        POSITION_TEX_LMAP_COLOR.addElement(TEX_2S);
        POSITION_TEX_LMAP_COLOR.addElement(COLOR_4UB);
        POSITION_TEX_COLOR_NORMAL.addElement(POSITION_3F);
        POSITION_TEX_COLOR_NORMAL.addElement(TEX_2F);
        POSITION_TEX_COLOR_NORMAL.addElement(COLOR_4UB);
        POSITION_TEX_COLOR_NORMAL.addElement(NORMAL_3B);
        POSITION_TEX_COLOR_NORMAL.addElement(PADDING_1B);
    }
}
