package net.minecraft.client.renderer;

import net.minecraftforge.fml.relauncher.Side;
import net.minecraftforge.fml.relauncher.SideOnly;

@SideOnly(Side.CLIENT)
public class TessellatorHelper
{
    private final BufferBuilderHelper buffer;
    private final WorldVertexBufferUploader vboUploader = new WorldVertexBufferUploader();
    private static final TessellatorHelper INSTANCE = new TessellatorHelper(2097152);

    public static TessellatorHelper getInstance()
    {
        return INSTANCE;
    }

    public TessellatorHelper(int bufferSize)
    {
        this.buffer = new BufferBuilderHelper(bufferSize);
    }

    public void draw() {}

    public BufferBuilderHelper getBuffer()
    {
        return this.buffer;
    }
}
