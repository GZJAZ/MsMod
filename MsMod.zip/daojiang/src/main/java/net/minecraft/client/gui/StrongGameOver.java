package net.minecraft.client.gui;

import com.google.common.collect.Lists;
import net.minecraft.client.Minecraft;
import net.minecraft.client.multiplayer.WorldClient;
import net.minecraft.client.renderer.*;
import net.minecraft.client.renderer.texture.TextureManagerHelper;
import net.minecraft.client.renderer.vertex.*;
import net.minecraft.client.resources.I18n;
import net.minecraft.client.resources.IResourceManager;
import net.minecraft.client.settings.GameSettings;
import net.minecraft.util.ResourceLocation;
import net.minecraft.util.text.ITextComponent;
import net.minecraft.util.text.TextFormatting;
import net.minecraftforge.fml.relauncher.Side;
import net.minecraftforge.fml.relauncher.SideOnly;
import org.lwjgl.input.Mouse;
import org.lwjgl.opengl.DraftGL;

import javax.annotation.Nullable;
import java.nio.ByteBuffer;
import java.util.List;

@SideOnly(Side.CLIENT)
public
class StrongGameOver {
    private int enableButtonsTimer;
    private final ITextComponent causeOfDeath;
    protected List<GuiButtonHelper> buttonList = Lists.<GuiButtonHelper>newArrayList();
    protected List<GuiLabelHelper> labelList = Lists.<GuiLabelHelper>newArrayList();
    protected List<IResourceManager> iResourceManagers = Lists.<IResourceManager>newArrayList();
    public Minecraft mc;
    public int width;
    public int height;
    protected FontRendererHelper fontRenderer;
    public float zLevel;

    public StrongGameOver(@Nullable ITextComponent causeOfDeathIn) {
        this.causeOfDeath = causeOfDeathIn;
        this.mc = Minecraft.getMinecraft();
        this.fontRenderer = FontRendererHelper.font();
        ScaledResolution scaledresolution = new ScaledResolution(this.mc);
        this.width = scaledresolution.getScaledWidth();
        this.height = scaledresolution.getScaledHeight();
    }

    public void initGui() {
        if (this.mc.world.getWorldInfo().isHardcoreModeEnabled()) {
            this.buttonList.add(new GuiButtonHelper(0, this.width / 2 - 100, this.height / 4 + 72, I18n.format("deathScreen.spectate")));
            this.buttonList.add(new GuiButtonHelper(1, this.width / 2 - 100, this.height / 4 + 96, I18n.format("deathScreen." + (this.mc.isIntegratedServerRunning() ? "deleteWorld" : "leaveServer"))));
        } else {
            this.buttonList.add(new GuiButtonHelper(0, this.width / 2 - 100, this.height / 4 + 72, I18n.format("deathScreen.respawn")));
            this.buttonList.add(new GuiButtonHelper(1, this.width / 2 - 100, this.height / 4 + 96, I18n.format("deathScreen.titleScreen")));
        }
        for (GuiButtonHelper guibutton : this.buttonList) {
            guibutton.enabled = false;
        }
    }


    public void confirmClicked(boolean result, int id) {
        if (result) {
            if (this.mc.world != null) {
                this.mc.world.sendQuittingDisconnectingPacket();
            }

            this.mc.loadWorld((WorldClient) null);
            this.mc.displayGuiScreen(new GuiMainMenu());
        } else {
            this.mc.player.respawnPlayer();
            this.mc.displayGuiScreen((GuiScreen) null);
        }
    }

    public void drawScreen() {
        int mouseX = 0, mouseY = 0;
        Mouse.setGrabbed(false);
        mc.currentScreen = null;
        boolean flag = false;
        int left = 0;
        int top = 0;
        float partialTicks = 0.0F;
        int right = this.width;
        int bottom = this.height;
        int startColor = 1615855616;
        int endColor = -1602211792;
        float f = (float) (startColor >> 24 & 255) / 255.0F;
        float f1 = (float) (startColor >> 16 & 255) / 255.0F;
        float f2 = (float) (0) / 255.0F;
        float f3 = (float) (0) / 255.0F;
        float f4 = (float) (endColor >> 24 & 255) / 255.0F;
        float f5 = (float) (endColor >> 16 & 255) / 255.0F;
        float f6 = (float) (endColor >> 8 & 255) / 255.0F;
        float f7 = (float) (endColor & 255) / 255.0F;
        GlStateManager.disableTexture2D();
        GlStateManager.enableBlend();
        GlStateManager.disableAlpha();
        GlStateManager.tryBlendFuncSeparate(GlStateManager.SourceFactor.SRC_ALPHA, GlStateManager.DestFactor.ONE_MINUS_SRC_ALPHA, GlStateManager.SourceFactor.ONE, GlStateManager.DestFactor.ZERO);
        GlStateManager.shadeModel(7425);
        TessellatorHelper tessellator = TessellatorHelper.getInstance();
        BufferBuilderHelper bufferbuilder = tessellator.getBuffer();
        bufferbuilder.begin(7, DefaultVertexFormatsHelper.POSITION_TEX_COLOR);
        bufferbuilder.pos((double) right, (double) top, (double) this.zLevel).color(f1, f2, f3, f).endVertex();
        bufferbuilder.pos((double) left, (double) top, (double) this.zLevel).color(f1, f2, f3, f).endVertex();
        bufferbuilder.pos((double) left, (double) bottom, (double) this.zLevel).color(f5, f6, f7, f4).endVertex();
        bufferbuilder.pos((double) right, (double) bottom, (double) this.zLevel).color(f5, f6, f7, f4).endVertex();
        bufferbuilder.finishDrawing();
        VertexFormatHelper vertexformat = bufferbuilder.getVertexFormat();
        int i = vertexformat.getNextOffset();
        ByteBuffer bytebuffer = bufferbuilder.getByteBuffer();
        List<VertexFormatElementHelper> list = vertexformat.getElements();
        for (int j = 0; j < list.size(); ++j) {
            VertexFormatElementHelper vertexformatelement = list.get(j);
            VertexFormatElementHelper.EnumUsage vertexformatelement$enumusage = vertexformatelement.getUsage();
            int k = vertexformatelement.getType().getGlConstant();
            int l = vertexformatelement.getIndex();
            bytebuffer.position(vertexformat.getOffset(j));
            vertexformatelement.getUsage().preDraw(vertexformat, j, i, bytebuffer);
        }
        GlStateManager.glDrawArrays(bufferbuilder.getDrawMode(), 0, bufferbuilder.getVertexCount());
        int i1 = 0;
        for (int j1 = list.size(); i1 < j1; ++i1) {
            VertexFormatElementHelper vertexformatelement1 = list.get(i1);
            VertexFormatElementHelper.EnumUsage vertexformatelement$enumusage1 = vertexformatelement1.getUsage();
            int k1 = vertexformatelement1.getIndex();
            vertexformatelement1.getUsage().postDraw(vertexformat, i1, i, bytebuffer);
        }
        bufferbuilder.reset();
        DraftGL.shadeModel(7424);
        GlStateManager.disableBlend();
        GlStateManager.enableAlpha();
        GlStateManager.enableTexture2D();
        DraftGL.pushMatrix();
        GlStateManager.scale(2.0F, 2.0F, 2.0F);
        drawCenteredString(this.fontRenderer, I18n.format(flag ? "deathScreen.title.hardcore" : "deathScreen.title"), this.width / 2 / 2, 30, 16777215);
        DraftGL.popMatrix();
        if (this.causeOfDeath != null) {
            this.drawCenteredString(this.fontRenderer, this.causeOfDeath.getFormattedText(), this.width / 2, 85, 16777215);
        }
        drawCenteredString(this.fontRenderer, I18n.format("deathScreen.score") + ": " + TextFormatting.YELLOW + this.mc.player.getScore(), this.width / 2, 100, 16777215);

        for (int s = 0; s < this.buttonList.size(); ++s) {
            this.buttonList.get(s).drawButton(mc, mouseX, mouseY, partialTicks);
        }

        for (int j = 0; j < this.labelList.size(); ++j) {
            this.labelList.get(j).drawLabel(this.mc, mouseX, mouseY);
        }
    }

    public void drawCenteredString(FontRendererHelper fontRendererIn, String text, int x, int y, int color) {
        fontRendererIn.drawStringWithShadow(text, (float) (x - fontRendererIn.getStringWidth(text) / 2), (float) y, color);
    }
}