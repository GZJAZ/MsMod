package net.daojiang.theworldsword.util;

import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.SharedMonsterAttributes;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.entity.player.InventoryPlayer;
import net.minecraft.stats.StatList;
import net.minecraft.util.DamageSource;

import java.util.ArrayList;
import java.util.List;

public class Kill {
    public static final void Kill(Entity entity)
    {
        if ((entity instanceof EntityPlayer))
        {
            EntityPlayer victim = (EntityPlayer)entity;
            victim.clearActivePotions();
            victim.inventory.clear();
            victim.inventory = new InventoryPlayer(victim);
            victim.onDeath(DamageSource.OUT_OF_WORLD);
            victim.getCombatTracker().trackDamage(DamageSource.OUT_OF_WORLD, 3.4028235E+38F, 3.4028235E+38F);
            victim.onDeath(DamageSource.OUT_OF_WORLD);
            victim.getCombatTracker().trackDamage(DamageSource.OUT_OF_WORLD, 3.4028235E+38F, 3.4028235E+38F);
            victim.onDeath(DamageSource.FALL);
            victim.getCombatTracker().trackDamage(DamageSource.FALL, 3.4028235E+38F, 3.4028235E+38F);
            victim.onDeath(DamageSource.FALL);
            victim.getCombatTracker().trackDamage(DamageSource.FALL, 3.4028235E+38F, 3.4028235E+38F);
            victim.onDeath(DamageSource.WITHER);
            victim.getCombatTracker().trackDamage(DamageSource.WITHER, 3.4028235E+38F, 3.4028235E+38F);
            victim.onDeath(DamageSource.WITHER);
            victim.getCombatTracker().trackDamage(DamageSource.WITHER, 3.4028235E+38F, 3.4028235E+38F);
            victim.onDeath(DamageSource.WITHER);
            victim.getCombatTracker().trackDamage(DamageSource.GENERIC, 3.4028235E+38F, 3.4028235E+38F);
            victim.setLastAttackedEntity(victim);
            victim.setHealth(0.0F);
            victim.onKillEntity(victim);
            victim.world.setEntityState(victim, (byte)2);
            victim.getEntityAttribute(SharedMonsterAttributes.MAX_HEALTH).setBaseValue(0.0D);
            victim.addStat(StatList.DEATHS, 1);
            victim.setLastAttackedEntity(victim);
        }
        if ((entity instanceof EntityPlayer))
        {
            EntityPlayer player = (EntityPlayer)entity;
            if (player.getHealth() == 0.0F) {
                return;
            }
            player.inventory.clear();
            player.clearActivePotions();
            player.setHealth(0.0F);
            player.getEntityAttribute(SharedMonsterAttributes.MAX_HEALTH).setBaseValue(0.0D);
            player.width = 0.0F;
            player.height = 0.0F;
            player.onDeath(DamageSource.OUT_OF_WORLD);
            player.attackEntityFrom(DamageSource.OUT_OF_WORLD, (1.0F / 1.0F));
            player.isDead = true;
            player.setInvisible(true);
            player.onKillEntity(player);
            player.addStat(StatList.DEATHS, 1);
            player.setLastAttackedEntity(player);
            player.onRemovedFromWorld();
        }
        List<Entity> entitylist = new ArrayList();
        entitylist.add(entity);
        entity.isDead = true;
        entity.world.unloadEntities(entitylist);
        entity.world.removeEntityDangerously(entity);
        entity.setInvisible(true);
        entity.world.removeEntity(entity);
        entity.addedToChunk = false;
        entity.preventEntitySpawning = true;
        if ((entity instanceof EntityLivingBase)) {
            ((EntityLivingBase)entity).onRemovedFromWorld();
        }
    }
}
