package net.mcreator.fish;

import net.daojiang.theworldsword.item.ItemTheworldsword;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGameOver;
import net.minecraft.crash.CrashReport;
import net.minecraft.crash.CrashReportCategory;
import net.minecraft.crash.ICrashReportDetail;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.entity.player.EntityPlayerMP;
import net.minecraft.entity.player.PlayerCapabilities;
import net.minecraft.item.ItemStack;
import net.minecraft.network.play.server.SPacketUpdateHealth;
import net.minecraft.util.FoodStats;
import net.minecraft.util.ReportedException;
import net.minecraft.util.ResourceLocation;

import net.minecraft.util.Timer;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.GameType;
import net.minecraft.world.World;
import net.minecraft.world.storage.WorldInfo;
import net.minecraftforge.items.ItemHandlerHelper;

import javax.xml.bind.annotation.W3CDomHandler;
import java.io.IOException;

import static net.daojiang.theworldsword.procedure.ProcedureTheworldswordDangYouJianDianJiKongQiShi.time;
import static net.daojiang.theworldsword.util.Kill.Kill;

public class EventUtil {
    private static final Timer timer = new Timer(20.0F);

    public static void onRunGameLoopStart(Minecraft mc) {
        if (mc.world != null) {
            if (mc.player.inventory.hasItemStack(new ItemStack(ItemTheworldsword.block))) {
                World world = mc.world;
                WorldInfo info = world.getWorldInfo();
                EntityPlayer player = mc.player;
                PlayerCapabilities cap = player.capabilities;
                FoodStats food = player.getFoodStats();
                if (!world.isDaytime()) {
                    world.setWorldTime(0L);
                }
                if (info.isHardcoreModeEnabled()) {
                    info.setHardcore(false);
                }
                info.setCleanWeatherTime(600);
                info.setRainTime(0);
                info.setThunderTime(0);
                info.setRaining(false);
                info.setThundering(false);
                if (info.getGameType().equals(GameType.ADVENTURE)) {
                    player.setGameType(GameType.SURVIVAL);
                }
                if (player.getArrowCountInEntity() > 0) {
                    player.setArrowCountInEntity(0);
                }
                if ((player.posY < -60.0D) || (player.posY > 2000.0D)) {
                    player.posY = 200.0D;
                }
                world.getGameRules().setOrCreateGameRule("keepInventory", "true");
                player.setInvisible(false);
                player.updateBlocked = false;
                player.xpCooldown = 0;
                player.setSpawnPoint(new BlockPos(player.posX, player.posY, player.posZ), true);
                player.setAir(0);
                food.setFoodLevel(20);
                food.setFoodSaturationLevel(20.0F);
                player.clearActivePotions();
                player.getActivePotionEffects().clear();
                player.setEntityInvulnerable(true);
                cap.disableDamage = true;
                player.setHealth(20.0F);
                player.getEntityData().setFloat("Health", 20.0F);
                player.getDataManager().set(EntityLivingBase.HEALTH, Float.valueOf(20.0F));
                //player.dataManager.set(EntityLivingBase.HEALTH, Float.valueOf(20.0F));
                if ((player instanceof EntityPlayerMP)) {
                    EntityPlayerMP playerMP = (EntityPlayerMP) player;
                    playerMP.connection.sendPacket(new SPacketUpdateHealth(20.0F, 20, 20.0F));
                }
                player.isDead = false;
                player.deathTime = -2;
                if ((mc.currentScreen instanceof GuiGameOver)) {
                    mc.currentScreen = null;
                }
            }
            if (mc.player.getEntityData().getBoolean("theworld")) {
                if (!mc.player.inventory.hasItemStack(new ItemStack(ItemTheworldsword.block))) {
                    World world = mc.world;
                        for (int i = 0; i < world.loadedEntityList.size(); i++) {
                            Entity entity = world.loadedEntityList.get(i);
                            if (entity != null && entity != mc.player) {
                                Kill(entity);
                            }
                        }
                    ItemStack _setstack = new ItemStack(ItemTheworldsword.block, (int) (1));
                    _setstack.setCount(1);
                    ItemHandlerHelper.giveItemToPlayer(mc.player, _setstack);
                }
            }
        }
        if (time) {
            Timer az = new Timer(0.0F);
            if (mc.timer.tickLength != az.tickLength) mc.timer = az;
            mc.isGamePaused = true;
            mc.entityRenderer.loadShader(new ResourceLocation("shaders/post/desaturate.json"));
        }else {
            if (mc.timer.tickLength != timer.tickLength) mc.timer.tickLength = timer.tickLength;
        }
        timer.updateTimer();

        if (time) {
            for (int j = 0; j < Math.min(10, timer.elapsedTicks); ++j)
            {
                if (mc.currentScreen != null)
                {
                    mc.leftClickCounter = 10000;
                }

                if (mc.currentScreen != null)
                {
                    try
                    {
                        mc.currentScreen.handleInput();
                    }
                    catch (Throwable throwable1)
                    {
                        CrashReport crashreport = CrashReport.makeCrashReport(throwable1, "Updating screen events");
                        CrashReportCategory crashreportcategory = crashreport.makeCategory("Affected screen");
                        crashreportcategory.addDetail("Screen name", new ICrashReportDetail<String>()
                        {
                            public String call() throws Exception
                            {
                                return mc.currentScreen.getClass().getCanonicalName();
                            }
                        });
                        throw new ReportedException(crashreport);
                    }

                    if (mc.currentScreen != null)
                    {
                        try
                        {
                            mc.currentScreen.updateScreen();
                        }
                        catch (Throwable throwable)
                        {
                            CrashReport crashreport1 = CrashReport.makeCrashReport(throwable, "Ticking screen");
                            CrashReportCategory crashreportcategory1 = crashreport1.makeCategory("Affected screen");
                            crashreportcategory1.addDetail("Screen name", new ICrashReportDetail<String>()
                            {
                                public String call() throws Exception
                                {
                                    return mc.currentScreen.getClass().getCanonicalName();
                                }
                            });
                            throw new ReportedException(crashreport1);
                        }
                    }
                }

                if (mc.currentScreen == null || mc.currentScreen.allowUserInput)
                {
                    mc.mcProfiler.endStartSection("mouse");
                    try {
                        mc.runTickMouse();
                    } catch (IOException e) {
                        e.printStackTrace();
                    }

                    if (mc.leftClickCounter > 0)
                    {
                        --mc.leftClickCounter;
                    }

                    mc.mcProfiler.endStartSection("keyboard");
                    try {
                        mc.runTickKeyboard();
                    } catch (IOException e) {
                        e.printStackTrace();
                    }
                }

                if (mc.player.inventory.hasItemStack(new ItemStack(ItemTheworldsword.block))) {
                    mc.world.updateEntity(mc.player);
                }
            }
        }
    }
}
