package net.daojiang.theworldsword.procedure;

import net.minecraft.entity.Entity;

import net.daojiang.theworldsword.ElementsTheworldswordMod;

import java.util.Map;

@ElementsTheworldswordMod.ModElement.Tag
public class ProcedureTheworldswordDangWuPinZaiBeiBaoZhongMeiKeFaSheng extends ElementsTheworldswordMod.ModElement {
	public ProcedureTheworldswordDangWuPinZaiBeiBaoZhongMeiKeFaSheng(ElementsTheworldswordMod instance) {
		super(instance, 2);
	}

	public static void executeProcedure(Map<String, Object> dependencies) {
		if (dependencies.get("entity") == null) {
			System.err.println("Failed to load dependency entity for procedure TheworldswordDangWuPinZaiBeiBaoZhongMeiKeFaSheng!");
			return;
		}
		Entity entity = (Entity) dependencies.get("entity");
		entity.getEntityData().setBoolean("theworld", (true));
	}
}
