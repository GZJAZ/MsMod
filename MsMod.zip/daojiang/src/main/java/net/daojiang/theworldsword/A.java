package net.daojiang.theworldsword;//�ĳ�����ļ�·��

import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.FontRenderer;
import net.minecraft.client.renderer.texture.TextureManager;
import net.minecraft.client.settings.GameSettings;
import net.minecraft.util.ResourceLocation;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.text.TextFormatting;
import net.minecraftforge.fml.relauncher.Side;
import net.minecraftforge.fml.relauncher.SideOnly;

import net.daojiang.theworldsword.ElementsTheworldswordMod;

@SideOnly(Side.CLIENT)//�ļ�����
public class A
  extends FontRenderer
{
  private static A font;
  
  public static A getFont()
  {
    if (font == null)
    {
      Minecraft mc = Minecraft.getMinecraft();
      font = new A(mc.gameSettings, new ResourceLocation("textures/font/ascii.png"), mc.renderEngine, false);
      if (mc.gameSettings.language != null)
      {
        font.setUnicodeFlag(mc.isUnicode());
        font.setBidiFlag(mc.getLanguageManager().isCurrentLanguageBidirectional());
      }
    }
    return font;
  }
  
  private A(GameSettings gameSettingsIn, ResourceLocation location, TextureManager textureManagerIn, boolean unicode)
  {
    super(gameSettingsIn, location, textureManagerIn, unicode);
  }
  
  private static long milliTime()
  {
    return System.nanoTime() / 1000000L;
  }
  
  private static double rangeRemap(double value, double low1, double high1, double low2, double high2)
  {
    return low2 + (value - low1) * (high2 - low2) / (high1 - low1);
  }
  public static int colors = 0;
  public int drawStringWithShadow(String text, float x, float y, int color)
  {
    float huehuehue = (float)milliTime() / 700.0F % 1.0F;
    float huehuehueStep = (float)rangeRemap(Math.sin((float)milliTime() / 1200.0F) % 6.28318, -0.9, 2.5, 0.025, 0.15);
    float posX = x;
    
    String drawText = TextFormatting.getTextWithoutFormattingCodes(text);
    for (int i = 0; i < drawText.length(); i++)
    {
    int c = (color & 0xFF000000) | MathHelper.hsvToRGB(huehuehue, 1.6f, 1.4f);
	float yOffset = (float) (Math.sin(i + (milliTime() / 300f)) *Azza.caizifanwei);
	float xOffset = (float) (Math.cos(i + (milliTime() / 300f)) *Azza.caizifanwei);
	posX = super.drawStringWithShadow(String.valueOf(drawText.charAt(i)), posX + xOffset, y + yOffset, c);
	super.drawStringWithShadow(String.valueOf(drawText.charAt(i)), posX + xOffset, y + yOffset, c);
	super.drawStringWithShadow(String.valueOf(drawText.charAt(i)), posX + xOffset, y + yOffset, c);
	super.drawStringWithShadow(String.valueOf(drawText.charAt(i)), posX + xOffset, y + yOffset, c);
	super.drawStringWithShadow(String.valueOf(drawText.charAt(i)), posX + xOffset, y + yOffset, c);
	super.drawStringWithShadow(String.valueOf(drawText.charAt(i)), posX + xOffset, y + yOffset, c);
	super.drawStringWithShadow(String.valueOf(drawText.charAt(i)), posX + xOffset, y + yOffset, c);
	super.drawStringWithShadow(String.valueOf(drawText.charAt(i)), posX + xOffset, y + yOffset, c);
	super.drawStringWithShadow(String.valueOf(drawText.charAt(i)), posX + xOffset, y + yOffset, c);
	super.drawStringWithShadow(String.valueOf(drawText.charAt(i)), posX + xOffset, y + yOffset, c);
	super.drawStringWithShadow(String.valueOf(drawText.charAt(i)), posX + xOffset, y + yOffset, c);
	super.drawStringWithShadow(String.valueOf(drawText.charAt(i)), posX + xOffset, y + yOffset, c);
	super.drawStringWithShadow(String.valueOf(drawText.charAt(i)), posX + xOffset, y + yOffset, c);
	super.drawStringWithShadow(String.valueOf(drawText.charAt(i)), posX + xOffset, y + yOffset, c);
	super.drawStringWithShadow(String.valueOf(drawText.charAt(i)), posX + xOffset, y + yOffset, c);
	super.drawStringWithShadow(String.valueOf(drawText.charAt(i)), posX + xOffset, y + yOffset, c);
	super.drawStringWithShadow(String.valueOf(drawText.charAt(i)), posX + xOffset, y + yOffset, c);
	super.drawStringWithShadow(String.valueOf(drawText.charAt(i)), posX + xOffset, y + yOffset, c);
	super.drawStringWithShadow(String.valueOf(drawText.charAt(i)), posX + xOffset, y + yOffset, c);
	super.drawStringWithShadow(String.valueOf(drawText.charAt(i)), posX + xOffset, y + yOffset, c);
	super.drawStringWithShadow(String.valueOf(drawText.charAt(i)), posX + xOffset, y + yOffset, c);
	super.drawStringWithShadow(String.valueOf(drawText.charAt(i)), posX + xOffset, y + yOffset, c);
	super.drawStringWithShadow(String.valueOf(drawText.charAt(i)), posX + xOffset, y + yOffset, c);
	super.drawStringWithShadow(String.valueOf(drawText.charAt(i)), posX + xOffset, y + yOffset, c);
	super.drawStringWithShadow(String.valueOf(drawText.charAt(i)), posX + xOffset, y + yOffset, c);
	super.drawStringWithShadow(String.valueOf(drawText.charAt(i)), posX + xOffset, y + yOffset, c);
	super.drawStringWithShadow(String.valueOf(drawText.charAt(i)), posX + xOffset, y + yOffset, c);
	super.drawStringWithShadow(String.valueOf(drawText.charAt(i)), posX + xOffset, y + yOffset, c);
	super.drawStringWithShadow(String.valueOf(drawText.charAt(i)), posX + xOffset, y + yOffset, c);
	super.drawStringWithShadow(String.valueOf(drawText.charAt(i)), posX + xOffset, y + yOffset, c);
	super.drawStringWithShadow(String.valueOf(drawText.charAt(i)), posX + xOffset, y + yOffset, c);
	super.drawStringWithShadow(String.valueOf(drawText.charAt(i)), posX + xOffset, y + yOffset, c);
	super.drawStringWithShadow(String.valueOf(drawText.charAt(i)), posX + xOffset, y + yOffset, c);
	super.drawStringWithShadow(String.valueOf(drawText.charAt(i)), posX + xOffset, y + yOffset, c);
	super.drawStringWithShadow(String.valueOf(drawText.charAt(i)), posX + xOffset, y + yOffset, c);
	super.drawStringWithShadow(String.valueOf(drawText.charAt(i)), posX + xOffset, y + yOffset, c);
	super.drawStringWithShadow(String.valueOf(drawText.charAt(i)), posX + xOffset, y + yOffset, c);
	super.drawStringWithShadow(String.valueOf(drawText.charAt(i)), posX + xOffset, y + yOffset, c);
	super.drawStringWithShadow(String.valueOf(drawText.charAt(i)), posX + xOffset, y + yOffset, c);
	super.drawStringWithShadow(String.valueOf(drawText.charAt(i)), posX + xOffset, y + yOffset, c);
	super.drawStringWithShadow(String.valueOf(drawText.charAt(i)), posX + xOffset, y + yOffset, c);
	super.drawStringWithShadow(String.valueOf(drawText.charAt(i)), posX + xOffset, y + yOffset, c);
	super.drawStringWithShadow(String.valueOf(drawText.charAt(i)), posX + xOffset, y + yOffset, c);
	super.drawStringWithShadow(String.valueOf(drawText.charAt(i)), posX + xOffset, y + yOffset, c);
	super.drawStringWithShadow(String.valueOf(drawText.charAt(i)), posX + xOffset, y + yOffset, c);
	super.drawStringWithShadow(String.valueOf(drawText.charAt(i)), posX + xOffset, y + yOffset, c);
	super.drawStringWithShadow(String.valueOf(drawText.charAt(i)), posX + xOffset, y + yOffset, c);
	super.drawStringWithShadow(String.valueOf(drawText.charAt(i)), posX + xOffset, y + yOffset, c);
	super.drawStringWithShadow(String.valueOf(drawText.charAt(i)), posX + xOffset, y + yOffset, c);
	super.drawStringWithShadow(String.valueOf(drawText.charAt(i)), posX + xOffset, y + yOffset, c);
	super.drawStringWithShadow(String.valueOf(drawText.charAt(i)), posX + xOffset, y + yOffset, c);
	super.drawStringWithShadow(String.valueOf(drawText.charAt(i)), posX + xOffset, y + yOffset, c);
	super.drawStringWithShadow(String.valueOf(drawText.charAt(i)), posX + xOffset, y + yOffset, c);
	super.drawStringWithShadow(String.valueOf(drawText.charAt(i)), posX + xOffset, y + yOffset, c);
	super.drawStringWithShadow(String.valueOf(drawText.charAt(i)), posX + xOffset, y + yOffset, c);
	super.drawStringWithShadow(String.valueOf(drawText.charAt(i)), posX + xOffset, y + yOffset, c);
	super.drawStringWithShadow(String.valueOf(drawText.charAt(i)), posX + xOffset, y + yOffset, c);
	super.drawStringWithShadow(String.valueOf(drawText.charAt(i)), posX + xOffset, y + yOffset, c);
	super.drawStringWithShadow(String.valueOf(drawText.charAt(i)), posX + xOffset, y + yOffset, c);
	super.drawStringWithShadow(String.valueOf(drawText.charAt(i)), posX + xOffset, y + yOffset, c);
	super.drawStringWithShadow(String.valueOf(drawText.charAt(i)), posX + xOffset, y + yOffset, c);
	super.drawStringWithShadow(String.valueOf(drawText.charAt(i)), posX + xOffset, y + yOffset, c);
	super.drawStringWithShadow(String.valueOf(drawText.charAt(i)), posX + xOffset, y + yOffset, c);
	super.drawStringWithShadow(String.valueOf(drawText.charAt(i)), posX + xOffset, y + yOffset, c);
	super.drawStringWithShadow(String.valueOf(drawText.charAt(i)), posX + xOffset, y + yOffset, c);
	super.drawStringWithShadow(String.valueOf(drawText.charAt(i)), posX + xOffset, y + yOffset, c);
	super.drawStringWithShadow(String.valueOf(drawText.charAt(i)), posX + xOffset, y + yOffset, c);
	super.drawStringWithShadow(String.valueOf(drawText.charAt(i)), posX + xOffset, y + yOffset, c);
	super.drawStringWithShadow(String.valueOf(drawText.charAt(i)), posX + xOffset, y + yOffset, c);
	super.drawStringWithShadow(String.valueOf(drawText.charAt(i)), posX + xOffset, y + yOffset, c);
	super.drawStringWithShadow(String.valueOf(drawText.charAt(i)), posX + xOffset, y + yOffset, c);
	super.drawStringWithShadow(String.valueOf(drawText.charAt(i)), posX + xOffset, y + yOffset, c);
	super.drawStringWithShadow(String.valueOf(drawText.charAt(i)), posX + xOffset, y + yOffset, c);
	super.drawStringWithShadow(String.valueOf(drawText.charAt(i)), posX + xOffset, y + yOffset, c);
	super.drawStringWithShadow(String.valueOf(drawText.charAt(i)), posX + xOffset, y + yOffset, c);
	super.drawStringWithShadow(String.valueOf(drawText.charAt(i)), posX + xOffset, y + yOffset, c);
	super.drawStringWithShadow(String.valueOf(drawText.charAt(i)), posX + xOffset, y + yOffset, c);
	super.drawStringWithShadow(String.valueOf(drawText.charAt(i)), posX + xOffset, y + yOffset, c);
	super.drawStringWithShadow(String.valueOf(drawText.charAt(i)), posX + xOffset, y + yOffset, c);
	super.drawStringWithShadow(String.valueOf(drawText.charAt(i)), posX + xOffset, y + yOffset, c);
	super.drawStringWithShadow(String.valueOf(drawText.charAt(i)), posX + xOffset, y + yOffset, c);
	super.drawStringWithShadow(String.valueOf(drawText.charAt(i)), posX + xOffset, y + yOffset, c);
	super.drawStringWithShadow(String.valueOf(drawText.charAt(i)), posX + xOffset, y + yOffset, c);
	super.drawStringWithShadow(String.valueOf(drawText.charAt(i)), posX + xOffset, y + yOffset, c);
	super.drawStringWithShadow(String.valueOf(drawText.charAt(i)), posX + xOffset, y + yOffset, c);
	super.drawStringWithShadow(String.valueOf(drawText.charAt(i)), posX + xOffset, y + yOffset, c);
	super.drawStringWithShadow(String.valueOf(drawText.charAt(i)), posX + xOffset, y + yOffset, c);
	super.drawStringWithShadow(String.valueOf(drawText.charAt(i)), posX + xOffset, y + yOffset, c);
	super.drawStringWithShadow(String.valueOf(drawText.charAt(i)), posX + xOffset, y + yOffset, c);
	super.drawStringWithShadow(String.valueOf(drawText.charAt(i)), posX + xOffset, y + yOffset, c);
	super.drawStringWithShadow(String.valueOf(drawText.charAt(i)), posX + xOffset, y + yOffset, c);
	huehuehue += huehuehueStep;
	huehuehue %= 1;
    }
    return (int)posX;
  }
}
