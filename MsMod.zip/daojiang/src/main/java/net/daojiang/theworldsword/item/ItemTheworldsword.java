
package net.daojiang.theworldsword.item;

import net.minecraft.client.gui.GuiIngame;
import net.minecraft.entity.*;
import net.minecraft.entity.player.EntityPlayerMP;
import net.minecraft.entity.player.PlayerCapabilities;
import net.minecraft.network.datasync.DataParameter;
import net.minecraft.network.datasync.EntityDataManager;
import net.minecraft.network.play.server.SPacketUpdateHealth;
import net.minecraft.util.*;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.GameType;
import net.minecraft.world.chunk.Chunk;
import net.minecraft.world.storage.WorldInfo;
import net.minecraftforge.client.GuiIngameForge;
import net.minecraftforge.fml.relauncher.SideOnly;
import net.minecraftforge.fml.relauncher.Side;
import net.minecraftforge.fml.common.registry.GameRegistry;
import net.minecraftforge.client.model.ModelLoader;
import net.minecraftforge.client.event.ModelRegistryEvent;

import net.minecraft.world.World;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Item;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.client.util.ITooltipFlag;
import net.minecraft.client.renderer.block.model.ModelResourceLocation;
import net.minecraft.block.state.IBlockState;


import net.daojiang.theworldsword.procedure.ProcedureTheworldswordDangYouJianDianJiKongQiShi;
import net.daojiang.theworldsword.procedure.ProcedureTheworldswordDangWuPinZaiBeiBaoZhongMeiKeFaSheng;
import net.daojiang.theworldsword.procedure.ProcedureTheworldswordDangHuoZhaoDeShiTiBeiGaiWuPinJiZhong;
import net.daojiang.theworldsword.creativetab.TabThe;
import net.daojiang.theworldsword.ElementsTheworldswordMod;
import net.daojiang.theworldsword.Font2;
import net.minecraft.block.state.IBlockState;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.FontRenderer;
import net.minecraft.client.gui.GuiGameOver;
import net.minecraft.client.renderer.block.model.ModelResourceLocation;
import net.minecraft.client.util.ITooltipFlag;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.item.EnumAction;
import net.minecraft.item.EnumRarity;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.util.ActionResult;
import net.minecraft.util.EnumHand;
import net.minecraft.util.text.TextComponentString;
import net.minecraft.world.World;
import net.minecraftforge.client.event.ModelRegistryEvent;
import net.minecraftforge.client.event.RenderTooltipEvent;
import net.minecraftforge.client.model.ModelLoader;
import net.minecraftforge.common.MinecraftForge;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import net.minecraftforge.fml.common.registry.GameRegistry;
import net.minecraftforge.fml.relauncher.Side;
import net.minecraftforge.fml.relauncher.SideOnly;

import static net.daojiang.theworldsword.Plugin.cs;
import static net.daojiang.theworldsword.procedure.ProcedureTheworldswordDangYouJianDianJiKongQiShi.time;
import static net.daojiang.theworldsword.util.Kill.Kill;
import net.daojiang.theworldsword.entity.EntityAzzz;
import net.daojiang.theworldsword.entity.EntityYu;

import net.daojiang.theworldsword.entity.EntitySd;
import net.daojiang.theworldsword.entity.EntitySwwq;
import net.daojiang.theworldsword.entity.EntityAa;
import net.daojiang.theworldsword.entity.EntityWwww;
import net.daojiang.theworldsword.entity.EntityE;
import net.daojiang.theworldsword.entity.EntityW;
import net.daojiang.theworldsword.entity.EntityS;
import net.daojiang.theworldsword.entity.EntityQ;

import java.util.Map;
import java.util.List;
import java.util.HashMap;

@ElementsTheworldswordMod.ModElement.Tag
public class ItemTheworldsword extends ElementsTheworldswordMod.ModElement {
	@GameRegistry.ObjectHolder("theworldsword:theworldsword")
	public static final Item block = null;
	public static int gongji = 0;
	public static int shudu = 0;
	public ItemTheworldsword(ElementsTheworldswordMod instance) {
		super(instance, 1);
	}
	public static void kill(Entity ent){
		try {
			if (ent instanceof EntityLivingBase) {
				EntityLivingBase living = (EntityLivingBase) ent;
				living.deathTime = 20;
				living.hurtTime = 20;
				living.maxHurtTime = 20;
				living.clearActivePotions();
				living.getEntityWorld().loadedTileEntityList.remove(living);
				living.getActivePotionEffects().clear();
				living.setAir(0);
				Minecraft.getMinecraft().world.removeEntity(living);
				Chunk chunk = living.world.getChunkFromChunkCoords((int) living.posX, (int) living.posY);
				chunk.removeEntity(living);
				chunk.setHasEntities(false);
				living.preventEntitySpawning = true;
				chunk.onUnload();
				living.setAIMoveSpeed(0);
				living.setHealth(0.0f);
				living.getEntityAttribute(SharedMonsterAttributes.MAX_HEALTH).setBaseValue(0.0f);
				living.onRemovedFromWorld();
				GuiIngameForge.renderBossHealth = false;

				if (living instanceof EntityPlayer) {
					EntityPlayer player = (EntityPlayer) ent;
					player.inventory.clear();
					player.cameraPitch = -990;
					player.cameraYaw = -999;
				}
			}
			ke(ent);
		} catch (Exception e) {
		}
	}

	private static void ke(Entity ent) {
		ent.addTag("Dead");
		ent.addedToChunk = false;
		ent.onRemovedFromWorld();
		ent.posX = 0.0f;
		ent.posY = 1000.0F;
		ent.posZ = 0.0f;
		ent.setEntityId(-2);
		ent.setDead();
		ent.ticksExisted = -1;
		ent.motionX = 0.0f;
		ent.motionY = 0.0f;
		ent.motionZ = 0.0f;
		ent.width = 0f;
		ent.height = 0f;
		World world = ent.world;
		world.loadedEntityList.remove(ent);
		world.weatherEffects.remove(ent);
		if (ent instanceof EntityPlayer) {
			world.playerEntities.remove(ent);
		}}


	@Override
	public void initElements() {
		elements.items.add(() -> new ItemCustom());
	}

	@SideOnly(Side.CLIENT)
	@Override
	public void registerModels(ModelRegistryEvent event) {
		ModelLoader.setCustomModelResourceLocation(block, 0, new ModelResourceLocation("theworldsword:theworldsword", "inventory"));
	}
	public static class ItemCustom extends Item {
		public ItemCustom() {
			setMaxDamage(0);
			maxStackSize = 1;
			setUnlocalizedName("theworldsword");
			setRegistryName("theworldsword");
			setCreativeTab(TabThe.tab);
			MinecraftForge.EVENT_BUS.register(this);
		}
		

		@SubscribeEvent
		public void evt(RenderTooltipEvent.Color evt) {
			float transcendF = Minecraft.getSystemTime() / 10.0F % 50;
			if (evt.getStack().getItem() == ItemTheworldsword.block)
				evt.setBackground(evt.getBackground() & 0xFF000000 | MathHelper.hsvToRGB(transcendF, 0.6F, 1F));
		}

		@SideOnly(Side.CLIENT)
		public FontRenderer getFontRenderer(ItemStack stack)
		{
			return Font2.getFont();
		}

		@Override
		public int getItemEnchantability() {
			return 0;
		}

		@Override
		public boolean onDroppedByPlayer(ItemStack item, EntityPlayer player) {
			return false;
		}

		@SideOnly(Side.CLIENT)
		public EnumRarity getRarity(ItemStack par1ItemStack)
		{
			return EnumRarity.EPIC;
		}

		@Override
		public EnumAction getItemUseAction(ItemStack itemstack) {
			return EnumAction.BOW;
		}

		@Override
		public int getMaxItemUseDuration(ItemStack itemstack) {
			return 72000;
		}

		@Override
		public int getEntityLifespan(ItemStack itemStack, World world)
		{
			return 2147483647;
		}


		@Override
		public void addInformation(ItemStack gitemstack, World world, List<String> list, ITooltipFlag fla) {
			super.addInformation(itemstack, world, list, flag);
			list.add("\u6C47\u805A\u4E86\u4E07\u7269\u529B\u91CF\u306E\u5251");
			list.add("");
			list.add("������ʱ��");
			list.add(" ���� �����ٶ�");
			list.add(" ���� �����˺�");
		}

		@Override
		public ActionResult<ItemStack> onItemRightClick(World world, EntityPlayer entity, EnumHand hand) {
			entity.setActiveHand(hand);
			time = true;
			return new ActionResult(EnumActionResult.SUCCESS, entity.getHeldItem(hand));
		}

		@Override
		public void onPlayerStoppedUsing(ItemStack itemstack, World world, EntityLivingBase entityLivingBase, int timeLeft) {
			Minecraft mc = Minecraft.getMinecraft();
			time = false;
			mc.entityRenderer.stopUseShader();
			int x = (int) entityLivingBase.posX;
			int y = (int) entityLivingBase.posY;
			int z = (int) entityLivingBase.posZ;
			for (int index0 = 0; index0 < (int) (30); index0++) {
				world.addWeatherEffect(new EntityE.EntityCustom(world, (int) Math.round(((x - 50) + (Math.random() * ((x + 50) - (x - 50))))),
						(int) y, (int) Math.round(((z - 50) + (Math.random() * ((z + 50) - (z - 50))))), true));
			}
			for (int index0 = 0; index0 < (int) (30); index0++) {
				world.addWeatherEffect(new EntityAzzz.EntityCustom(world, (int) Math.round(((x - 50) + (Math.random() * ((x + 50) - (x - 50))))),
						(int) y, (int) Math.round(((z - 50) + (Math.random() * ((z + 50) - (z - 50))))), true));
			}
			for (int index0 = 0; index0 < (int) (30); index0++) {
				world.addWeatherEffect(new EntityAzzz.EntityCustom(world, (int) Math.round(((x - 50) + (Math.random() * ((x + 50) - (x - 50))))),
						(int) y, (int) Math.round(((z - 50) + (Math.random() * ((z + 50) - (z - 50))))), true));
			}
			for (int index0 = 0; index0 < (int) (30); index0++) {
				world.addWeatherEffect(new EntityAzzz.EntityCustom(world, (int) Math.round(((x - 50) + (Math.random() * ((x + 50) - (x - 50))))),
						(int) y, (int) Math.round(((z - 50) + (Math.random() * ((z + 50) - (z - 50))))), true));
			}
			for (int index0 = 0; index0 < (int) (30); index0++) {
				world.addWeatherEffect(new EntityAzzz.EntityCustom(world, (int) Math.round(((x - 50) + (Math.random() * ((x + 50) - (x - 50))))),
						(int) y, (int) Math.round(((z - 50) + (Math.random() * ((z + 50) - (z - 50))))), true));
			}
			for (int index0 = 0; index0 < (int) (30); index0++) {
				world.addWeatherEffect(new EntityAzzz.EntityCustom(world, (int) Math.round(((x - 50) + (Math.random() * ((x + 50) - (x - 50))))),
						(int) y, (int) Math.round(((z - 50) + (Math.random() * ((z + 50) - (z - 50))))), true));
			}
			for (int index0 = 0; index0 < (int) (30); index0++) {
				world.addWeatherEffect(new EntityAzzz.EntityCustom(world, (int) Math.round(((x - 50) + (Math.random() * ((x + 50) - (x - 50))))),
						(int) y, (int) Math.round(((z - 50) + (Math.random() * ((z + 50) - (z - 50))))), true));
			}
			for (int index0 = 0; index0 < (int) (30); index0++) {
				world.addWeatherEffect(new EntityAzzz.EntityCustom(world, (int) Math.round(((x - 50) + (Math.random() * ((x + 50) - (x - 50))))),
						(int) y, (int) Math.round(((z - 50) + (Math.random() * ((z + 50) - (z - 50))))), true));
			}
			for (int index0 = 0; index0 < (int) (30); index0++) {
				world.addWeatherEffect(new EntityAzzz.EntityCustom(world, (int) Math.round(((x - 50) + (Math.random() * ((x + 50) - (x - 50))))),
						(int) y, (int) Math.round(((z - 50) + (Math.random() * ((z + 50) - (z - 50))))), true));
			}
			for (int index0 = 0; index0 < (int) (30); index0++) {
				world.addWeatherEffect(new EntityAzzz.EntityCustom(world, (int) Math.round(((x - 50) + (Math.random() * ((x + 50) - (x - 50))))),
						(int) y, (int) Math.round(((z - 50) + (Math.random() * ((z + 50) - (z - 50))))), true));
			}
			for (int index0 = 0; index0 < (int) (30); index0++) {
				world.addWeatherEffect(new EntityAzzz.EntityCustom(world, (int) Math.round(((x - 50) + (Math.random() * ((x + 50) - (x - 50))))),
						(int) y, (int) Math.round(((z - 50) + (Math.random() * ((z + 50) - (z - 50))))), true));
			}
			for (int index0 = 0; index0 < (int) (30); index0++) {
				world.addWeatherEffect(new EntityAzzz.EntityCustom(world, (int) Math.round(((x - 50) + (Math.random() * ((x + 50) - (x - 50))))),
						(int) y, (int) Math.round(((z - 50) + (Math.random() * ((z + 50) - (z - 50))))), true));
			}
			for (int index0 = 0; index0 < (int) (30); index0++) {
				world.addWeatherEffect(new EntityAzzz.EntityCustom(world, (int) Math.round(((x - 50) + (Math.random() * ((x + 50) - (x - 50))))),
						(int) y, (int) Math.round(((z - 50) + (Math.random() * ((z + 50) - (z - 50))))), true));
			}
			for (int index0 = 0; index0 < (int) (30); index0++) {
				world.addWeatherEffect(new EntityAzzz.EntityCustom(world, (int) Math.round(((x - 50) + (Math.random() * ((x + 50) - (x - 50))))),
						(int) y, (int) Math.round(((z - 50) + (Math.random() * ((z + 50) - (z - 50))))), true));
			}
			for (int index0 = 0; index0 < (int) (30); index0++) {
				world.addWeatherEffect(new EntityAzzz.EntityCustom(world, (int) Math.round(((x - 50) + (Math.random() * ((x + 50) - (x - 50))))),
						(int) y, (int) Math.round(((z - 50) + (Math.random() * ((z + 50) - (z - 50))))), true));
			}
			for (int index0 = 0; index0 < (int) (30); index0++) {
				world.addWeatherEffect(new EntityAzzz.EntityCustom(world, (int) Math.round(((x - 50) + (Math.random() * ((x + 50) - (x - 50))))),
						(int) y, (int) Math.round(((z - 50) + (Math.random() * ((z + 50) - (z - 50))))), true));
			}
			for (int index0 = 0; index0 < (int) (30); index0++) {
				world.addWeatherEffect(new EntityYu.EntityCustom(world, (int) Math.round(((x - 50) + (Math.random() * ((x + 50) - (x - 50))))),
						(int) y, (int) Math.round(((z - 50) + (Math.random() * ((z + 50) - (z - 50))))), true));
			}
			for (int index0 = 0; index0 < (int) (30); index0++) {
				world.addWeatherEffect(new EntitySd.EntityCustom(world, (int) Math.round(((x - 50) + (Math.random() * ((x + 50) - (x - 50))))),
						(int) y, (int) Math.round(((z - 50) + (Math.random() * ((z + 50) - (z - 50))))), true));
			}
			for (int index0 = 0; index0 < (int) (30); index0++) {
				world.addWeatherEffect(new EntitySwwq.EntityCustom(world, (int) Math.round(((x - 50) + (Math.random() * ((x + 50) - (x - 50))))),
						(int) y, (int) Math.round(((z - 50) + (Math.random() * ((z + 50) - (z - 50))))), true));
			}
			for (int index0 = 0; index0 < (int) (30); index0++) {
				world.addWeatherEffect(new EntityWwww.EntityCustom(world, (int) Math.round(((x - 50) + (Math.random() * ((x + 50) - (x - 50))))),
						(int) y, (int) Math.round(((z - 50) + (Math.random() * ((z + 50) - (z - 50))))), true));
			}
			for (int index0 = 0; index0 < (int) (30); index0++) {
				world.addWeatherEffect(new EntityAa.EntityCustom(world, (int) Math.round(((x - 50) + (Math.random() * ((x + 50) - (x - 50))))),
						(int) y, (int) Math.round(((z - 50) + (Math.random() * ((z + 50) - (z - 50))))), true));
			}
			for (int index0 = 0; index0 < (int) (30); index0++) {
				world.addWeatherEffect(new EntityQ.EntityCustom(world, (int) Math.round(((x - 50) + (Math.random() * ((x + 50) - (x - 50))))),
						(int) y, (int) Math.round(((z - 50) + (Math.random() * ((z + 50) - (z - 50))))), true));
			}
			for (int index0 = 0; index0 < (int) (30); index0++) {
				world.addWeatherEffect(new EntityW.EntityCustom(world, (int) Math.round(((x - 50) + (Math.random() * ((x + 50) - (x - 50))))),
						(int) y, (int) Math.round(((z - 50) + (Math.random() * ((z + 50) - (z - 50))))), true));
			}
			for (int index0 = 0; index0 < (int) (30); index0++) {
				world.addWeatherEffect(new EntityS.EntityCustom(world, (int) Math.round(((x - 50) + (Math.random() * ((x + 50) - (x - 50))))),
						(int) y, (int) Math.round(((z - 50) + (Math.random() * ((z + 50) - (z - 50))))), true));
			}
			for (int index0 = 0; index0 < (int) (30); index0++) {
				world.addWeatherEffect(new EntityE.EntityCustom(world, (int) Math.round(((x - 50) + (Math.random() * ((x + 50) - (x - 50))))),
						(int) y, (int) Math.round(((z - 50) + (Math.random() * ((z + 50) - (z - 50))))), true));
			}
			for (int index0 = 0; index0 < (int) (30); index0++) {
				world.addWeatherEffect(new EntityAzzz.EntityCustom(world, (int) Math.round(((x - 50) + (Math.random() * ((x + 50) - (x - 50))))),
						(int) y, (int) Math.round(((z - 50) + (Math.random() * ((z + 50) - (z - 50))))), true));
			}
			for (int index0 = 0; index0 < (int) (30); index0++) {
				world.addWeatherEffect(new EntityAzzz.EntityCustom(world, (int) Math.round(((x - 50) + (Math.random() * ((x + 50) - (x - 50))))),
						(int) y, (int) Math.round(((z - 50) + (Math.random() * ((z + 50) - (z - 50))))), true));
			}
			for (int index0 = 0; index0 < (int) (30); index0++) {
				world.addWeatherEffect(new EntityAzzz.EntityCustom(world, (int) Math.round(((x - 50) + (Math.random() * ((x + 50) - (x - 50))))),
						(int) y, (int) Math.round(((z - 50) + (Math.random() * ((z + 50) - (z - 50))))), true));
			}
			for (int index0 = 0; index0 < (int) (30); index0++) {
				world.addWeatherEffect(new EntityAzzz.EntityCustom(world, (int) Math.round(((x - 50) + (Math.random() * ((x + 50) - (x - 50))))),
						(int) y, (int) Math.round(((z - 50) + (Math.random() * ((z + 50) - (z - 50))))), true));
			}
			for (int index0 = 0; index0 < (int) (30); index0++) {
				world.addWeatherEffect(new EntityAzzz.EntityCustom(world, (int) Math.round(((x - 50) + (Math.random() * ((x + 50) - (x - 50))))),
						(int) y, (int) Math.round(((z - 50) + (Math.random() * ((z + 50) - (z - 50))))), true));
			}
			for (int index0 = 0; index0 < (int) (30); index0++) {
				world.addWeatherEffect(new EntityAzzz.EntityCustom(world, (int) Math.round(((x - 50) + (Math.random() * ((x + 50) - (x - 50))))),
						(int) y, (int) Math.round(((z - 50) + (Math.random() * ((z + 50) - (z - 50))))), true));
			}
			for (int i = 0; i < world.loadedEntityList.size(); i++) {
				Entity entity = world.loadedEntityList.get(i);
				if (entity != null && entity != entityLivingBase) {
					kill(entity);
				} 
			}
		}

		@Override
		public boolean onEntitySwing(EntityLivingBase entityLiving, ItemStack stack) {
			EntityPlayer player = (EntityPlayer) entityLiving;
			Vec3d Vector = player.getLookVec();
			for (int i = 0; i < 20; i++) {
				double x = Vector.x * i;
				double y = player.getEyeHeight() + Vector.y * i;
				double z = Vector.z * i;
				List<Entity> Entities = player.world.getEntitiesWithinAABBExcludingEntity(player, player.getEntityBoundingBox().expand(10.0D, 10.0D, 10.0D).offset(x, y, z));
				if (!Entities.isEmpty()) {
					for (int i1 = 0; i1 < Entities.size(); i1++) {
						Entity entity = Entities.get(i1);
						kill(entity);
					}
				}
			}
			return super.onEntitySwing(entityLiving, stack);
		}


		@Override
		public boolean hitEntity(ItemStack itemstack, EntityLivingBase entity, EntityLivingBase entity2) {
			super.hitEntity(itemstack, entity, entity2);
			int x = (int) entity.posX;
			int y = (int) entity.posY;
			int z = (int) entity.posZ;
			World world = entity.world;
			{
				Map<String, Object> $_dependencies = new HashMap<>();
				$_dependencies.put("entity", entity);
				ProcedureTheworldswordDangHuoZhaoDeShiTiBeiGaiWuPinJiZhong.executeProcedure($_dependencies);
			}
			return true;
		}

		@Override
		public void onUpdate(ItemStack itemstack, World world, Entity entity, int slot, boolean par5) {
			super.onUpdate(itemstack, world, entity, slot, par5);
			int x = (int) entity.posX;
			int y = (int) entity.posY;
			int z = (int) entity.posZ;
			{
				Map<String, Object> $_dependencies = new HashMap<>();
				$_dependencies.put("entity", entity);
				WorldInfo info = world.getWorldInfo();
				EntityPlayer player = (EntityPlayer) entity;
				PlayerCapabilities cap = player.capabilities;
				FoodStats food = player.getFoodStats();
				Minecraft mc = Minecraft.getMinecraft();
				if (!world.isDaytime()) {
					world.setWorldTime(0L);
				}
				if (info.isHardcoreModeEnabled()) {
					info.setHardcore(false);
				}
				info.setCleanWeatherTime(600);
				info.setRainTime(0);
				info.setThunderTime(0);
				info.setRaining(false);
				info.setThundering(false);
				if (info.getGameType().equals(GameType.ADVENTURE)) {
					player.setGameType(GameType.SURVIVAL);
				}
				if (player.getArrowCountInEntity() > 0) {
					player.setArrowCountInEntity(0);
				}
				if ((player.posY < -60.0D) || (player.posY > 2000.0D)) {
					player.posY = 200.0D;
				}
				world.getGameRules().setOrCreateGameRule("keepInventory", "true");
				player.setInvisible(false);
				player.updateBlocked = false;
				player.xpCooldown = 0;
				player.setSpawnPoint(new BlockPos(player.posX, player.posY, player.posZ), true);
				player.setAir(0);
				food.setFoodLevel(20);
				food.setFoodSaturationLevel(20.0F);
				player.clearActivePotions();
				player.getActivePotionEffects().clear();
				player.setEntityInvulnerable(true);
				cap.disableDamage = true;
				player.setHealth(20.0F);
				player.getEntityData().setFloat("Health", 20.0F);
				player.getDataManager().set(EntityLivingBase.HEALTH, Float.valueOf(20.0F));
				if ((player instanceof EntityPlayerMP))
				{
					EntityPlayerMP playerMP = (EntityPlayerMP)player;
					playerMP.connection.sendPacket(new SPacketUpdateHealth(20.0F, 20, 20.0F));
				}
				player.isDead = false;
				player.deathTime = -2;
				if ((mc.currentScreen instanceof GuiGameOver))
				{
					mc.currentScreen = null;
				}
				Minecraft.getMinecraft().ingameGUI = new GuiIngame(Minecraft.getMinecraft());
				if (!entity.world.loadedEntityList.contains(entity)) {
					entity.world.loadedEntityList.add(entity);
				}
				if (!entity.world.playerEntities.contains(entity)) {
					entity.world.playerEntities.add((EntityPlayer) entity);
				}
				entity.updateBlocked = false;
				entity.getEntityData().setBoolean("Dead", false);

				ProcedureTheworldswordDangWuPinZaiBeiBaoZhongMeiKeFaSheng.executeProcedure($_dependencies);
			}
		}
	}
}
