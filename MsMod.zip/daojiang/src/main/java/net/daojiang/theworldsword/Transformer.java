package net.daojiang.theworldsword;

import org.objectweb.asm.*;
import net.minecraft.launchwrapper.IClassTransformer;

public class Transformer implements IClassTransformer {
    @Override
    public byte[] transform(String name, String transformedName, byte[] basicClass) {
        if (name.equals("bib") || transformedName.equals("net.minecraft.client.Minecraft")) {
            ClassReader Reader = new ClassReader(basicClass);
            ClassWriter Writer = new ClassWriter(Reader, 1);
            ClassVisitor Visitor = new ClassVisitor(Opcodes.ASM4, Writer) {
                @Override
                public MethodVisitor visitMethod(int access, String name, String desc, String signature, String[] exceptions) {
                    if ((name.equals("runGameLoop") || name.equals("func_71411_J") || name.equals("az")) && desc.equals("()V"))
                        return new MethodVisitor(262144, this.cv.visitMethod(access, name, desc, signature, exceptions)) {
                            public void visitCode() {
                                super.visitCode();
                                this.mv.visitVarInsn(25, 0);
                                this.mv.visitMethodInsn(184, "net/mcreator/fish/EventUtil", "onRunGameLoopStart", "(Lnet/minecraft/client/Minecraft;)V", false);
                            }
                        };
                    if (access == Opcodes.ACC_PRIVATE) access = Opcodes.ACC_PUBLIC;
                    return super.visitMethod(access, name, desc, signature, exceptions);
                }

                @Override
                public FieldVisitor visitField(int access, String name, String desc, String signature, Object value) {
                    if (access == Opcodes.ACC_PRIVATE + Opcodes.ACC_FINAL) access = Opcodes.ACC_PUBLIC;
                    if (access == Opcodes.ACC_PRIVATE) access = Opcodes.ACC_PUBLIC;
                    return super.visitField(access, name, desc, signature, value);
                }
            };
            Reader.accept(Visitor, Opcodes.ASM4);
            return Writer.toByteArray();
        }
        ClassReader Reader = new ClassReader(basicClass);
        ClassWriter Writer = new ClassWriter(Reader, 1);
        ClassVisitor Visitor = new ClassVisitor(Opcodes.ASM4, Writer) {

            @Override
            public FieldVisitor visitField(int access, String name, String desc, String signature, Object value) {
                if (access == Opcodes.ACC_PRIVATE + Opcodes.ACC_FINAL) access = Opcodes.ACC_PUBLIC + Opcodes.ACC_FINAL;
                if (access == Opcodes.ACC_PRIVATE) access = Opcodes.ACC_PUBLIC;
                return super.visitField(access, name, desc, signature, value);
            }
        };
        Reader.accept(Visitor, Opcodes.ASM4);
        return Writer.toByteArray();
    }
}
