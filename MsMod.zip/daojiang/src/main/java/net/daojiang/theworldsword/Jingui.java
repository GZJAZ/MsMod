/**
 * This mod element is always locked. Enter your code in the methods below.
 * If you don't need some of these methods, you can remove them as they
 * are overrides of the base class ElementsOverMod.ModElement.
 *
 * You can register new events in this class too.
 *
 * As this class is loaded into mod element list, it NEEDS to extend
 * ModElement class. If you remove this extend statement or remove the
 * constructor, the compilation will fail.
 *
 * If you want to make a plain independent class, create it in
 * "Workspace" -> "Source" menu.
 *
 * If you change workspace package, modid or prefix, you will need
 * to manually adapt this file to these changes or remake it.
*/
package net.daojiang.theworldsword;

import net.minecraft.client.gui.GuiGameOver;
import net.minecraftforge.client.event.GuiOpenEvent;
import net.minecraftforge.common.MinecraftForge;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;

@ElementsTheworldswordMod.ModElement.Tag
public class Jingui extends ElementsTheworldswordMod.ModElement {

	public Jingui(ElementsTheworldswordMod instance) {
		super(instance, 26);
			MinecraftForge.EVENT_BUS.register(this);
	}

	public static boolean ccc = false;

	@SubscribeEvent
    public void nb(GuiOpenEvent g){
    	if (ccc){
        if (g.getGui() instanceof GuiGameOver){
            g.setCanceled(true);
        }
    }
    }
}