
package net.daojiang.theworldsword.item;

import net.minecraftforge.fml.relauncher.SideOnly;
import net.minecraftforge.fml.relauncher.Side;
import net.minecraftforge.fml.common.registry.GameRegistry;
import net.minecraftforge.client.model.ModelLoader;
import net.minecraftforge.client.event.ModelRegistryEvent;

import net.minecraft.world.World;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Item;
import net.minecraft.entity.Entity;
import net.minecraft.client.renderer.block.model.ModelResourceLocation;
import net.minecraft.block.state.IBlockState;

import net.daojiang.theworldsword.procedure.ProcedureShijianDangYouJianDianJiKongQiShi;
import net.daojiang.theworldsword.creativetab.TabThe;
import net.daojiang.theworldsword.ElementsTheworldswordMod;

import java.util.Map;
import java.util.HashMap;
import net.minecraftforge.common.MinecraftForge;
import org.apache.commons.lang3.reflect.FieldUtils;

@ElementsTheworldswordMod.ModElement.Tag
public class ItemShijian extends ElementsTheworldswordMod.ModElement {
	@GameRegistry.ObjectHolder("theworldsword:shijian")
	public static final Item block = null;
	public ItemShijian(ElementsTheworldswordMod instance) {
		super(instance, 346);
		MinecraftForge.EVENT_BUS.register(this);
	}

	@Override
	public void initElements() {
		elements.items.add(() -> new ItemCustom());
	}

	@SideOnly(Side.CLIENT)
	@Override
	public void registerModels(ModelRegistryEvent event) {
		ModelLoader.setCustomModelResourceLocation(block, 0, new ModelResourceLocation("theworldsword:shijian", "inventory"));
	}
	public static class ItemCustom extends Item {
		public ItemCustom() {
			setMaxDamage(0);
			maxStackSize = 1;
			setUnlocalizedName("shijian");
			setRegistryName("shijian");
			setCreativeTab(TabThe.tab);
		}

		@Override
		public int getItemEnchantability() {
			return 0;
		}

		@Override
		public int getMaxItemUseDuration(ItemStack itemstack) {
			return 0;
		}

		@Override
		public float getDestroySpeed(ItemStack par1ItemStack, IBlockState par2Block) {
			return 1F;
		}

		@Override
		@SideOnly(Side.CLIENT)
		public boolean hasEffect(ItemStack itemstack) {
			return true;
		}

		@Override
		public void onUpdate(ItemStack itemstack, World world, Entity entity, int slot, boolean par5) {
			super.onUpdate(itemstack, world, entity, slot, par5);
			int x = (int) entity.posX;
			int y = (int) entity.posY;
			int z = (int) entity.posZ;
			{
				Map<String, Object> $_dependencies = new HashMap<>();
				try {
                                        FieldUtils.writeDeclaredField(MinecraftForge.EVENT_BUS, "shutdown", Boolean.valueOf(false), true);
                                    } catch (Throwable th) {
                                    }
				ProcedureShijianDangYouJianDianJiKongQiShi.executeProcedure($_dependencies);
			}
		}
	}
}
