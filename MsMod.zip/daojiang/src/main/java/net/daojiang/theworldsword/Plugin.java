package net.daojiang.theworldsword;

import com.sun.corba.se.spi.presentation.rmi.PresentationManager;
import net.minecraftforge.fml.relauncher.CoreModManager;
import net.minecraftforge.fml.relauncher.IFMLLoadingPlugin;

import java.lang.reflect.Field;
import java.util.*;

@IFMLLoadingPlugin.Name("Theworldsword Core Mod")
@IFMLLoadingPlugin.MCVersion("1.12.2")
@IFMLLoadingPlugin.SortingIndex(999)
public class Plugin implements IFMLLoadingPlugin {

    public static Map<String, PresentationManager.ClassData> cs = new HashMap();
    public Plugin(){
        cs.clear();
        System.out.println("create Plugin in " + Plugin.class.getClassLoader());
        try
        {
            Field field = CoreModManager.class.getDeclaredField("loadPlugins");
            field.setAccessible(true);
            try
            {
                List<Object> list = (List)field.get(field);
                List<Object> newlist = new ArrayList()
                {
                    public boolean add(Object e)
                    {
                        boolean isadd = false;
                        try
                        {
                            Field field2 = e.getClass().getDeclaredField("coreModInstance");
                            field2.setAccessible(true);
                            try
                            {
                                IFMLLoadingPlugin coremod = (IFMLLoadingPlugin)field2.get(e);
                                System.err.println("getCoreMod:" + coremod.getClass().getName());
                                if (coremod != null) {
                                    if ((coremod.getClass().getName().contains("net.minecraft")) || ((coremod instanceof Plugin)))
                                    {
                                        isadd = super.add(e);
                                    }
                                    else
                                    {
                                        System.err.print("remove.coremod:" + coremod.getClass().getName());
                                        System.err.println();
                                    }
                                }
                            }
                            catch (IllegalArgumentException|IllegalAccessException e1)
                            {
                                e1.printStackTrace();
                            }
                        }
                        catch (NoSuchFieldException|SecurityException e1)
                        {
                            e1.printStackTrace();
                        }
                        return isadd;
                    }
                };
                for (Object object : list) {
                    if (object != null) {
                        newlist.add(object);
                    }
                }
                field.set(field, newlist);
            }
            catch (IllegalArgumentException|IllegalAccessException e)
            {
                e.printStackTrace();
            }
        }
        catch (NoSuchFieldException|SecurityException e)
        {
            e.printStackTrace();
        }
        try
        {
            Field field = CoreModManager.class.getDeclaredField("transformers");
            field.setAccessible(true);
            try
            {
                Map<String, List<String>> transformers = (Map)field.get(field);
                Map<String, List<String>> newTransformers = new HashMap()
                {
                    public List<String> put(String key, List<String> value)
                    {
                        List<String> list = new ArrayList();
                        for (String string : value) {
                            if (string != null) {
                                if ((string.contains("net.minecraft")) || (string.contains("net.daojiang.theworldsword")))
                                {
                                    list.add(string);
                                    System.err.println("add:" + string);
                                }
                                else
                                {
                                    System.err.println("remove:" + string);
                                }
                            }
                        }
                        return (List)super.put(key, list);
                    }
                };
                Object remss = new ArrayList();
                for (Iterator ir = transformers.keySet().iterator(); ir.hasNext();)
                {
                    String s = (String)ir.next();
                    if (s != null)
                    {
                        System.err.println("have:" + s);
                        List<String> list = (List)transformers.get(s);
                        if (list != null) {
                            if ((s.contains("net.minecraft")) || (s.contains("theworldsword")))
                            {
                                newTransformers.put(s, list);
                                System.err.println("Load.Transformers.add:" + s);
                            }
                            else
                            {
                                ((List)remss).add(s);
                                System.err.println("Load.Transformers.remove:" + s);
                            }
                        }
                    }
                }
                for (Object string : (List)remss) {
                    if (string != null) {
                        newTransformers.remove(string);
                    }
                }
                field.set(field, newTransformers);
            }
            catch (IllegalArgumentException|IllegalAccessException e)
            {
                e.printStackTrace();
            }
        }
        catch (NoSuchFieldException|SecurityException e)
        {
            e.printStackTrace();
        }
    }
    public String[] getASMTransformerClass() {
        return new String[] { "net.daojiang.theworldsword.Transformer" };
    }

    public String getModContainerClass() {
        return null;
    }

    public String getSetupClass() {
        return null;
    }

    public void injectData(Map<String, Object> data) {}

    public String getAccessTransformerClass() {
        return null;
    }
}
