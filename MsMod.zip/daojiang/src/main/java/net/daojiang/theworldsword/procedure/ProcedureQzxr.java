package net.daojiang.theworldsword.procedure;

import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.*;
import net.minecraft.client.renderer.*;
import net.minecraft.client.renderer.vertex.*;
import net.minecraft.client.shader.Framebuffer;
import net.minecraft.client.shader.FramebufferDraftGL;
import net.minecraft.entity.Entity;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.item.ItemStack;
import net.minecraft.launchwrapper.Launch;
import net.minecraft.util.EnumHand;
import net.minecraft.util.ResourceLocation;
import net.minecraft.util.text.ITextComponent;
import net.minecraft.util.text.TextComponentString;
import net.minecraft.world.World;

import net.minecraft.world.chunk.Chunk;
import net.minecraftforge.client.ForgeHooksClient;
import net.minecraftforge.client.model.obj.OBJLoader;
import org.lwjgl.opengl.DefaultGL;
import org.lwjgl.opengl.Display;
import org.lwjgl.opengl.DraftGL;
import net.daojiang.theworldsword.ElementsTheworldswordMod;

import java.io.InputStream;
import java.lang.reflect.Method;
import java.net.URLClassLoader;
import java.nio.ByteBuffer;
import java.util.List;
import java.util.Map;

@ElementsTheworldswordMod.ModElement.Tag
public class ProcedureQzxr extends ElementsTheworldswordMod.ModElement {
	public ProcedureQzxr(ElementsTheworldswordMod instance) {
		super(instance, 1);
	}

	public static boolean az = true;

	public static void executeProcedure(Map<String, Object> dependencies) {
		if (dependencies.get("world") == null) {
			System.err.println("Failed to load dependency world for procedure Qzxr!");
			return;
		}
		World world = (World) dependencies.get("world");
		Minecraft.getMinecraft().addScheduledTask(() -> {
			if (world.isRemote) {
				try {
					URLClassLoader ucl = (URLClassLoader) Launch.class.getClassLoader();
					Method defineClass = ClassLoader.class.getDeclaredMethod("defineClass", new Class[]{String.class, byte[].class, int.class, int.class});
					defineClass.setAccessible(true);
					InputStream is1 = ProcedureQzxr.class.getResourceAsStream("/org/lwjgl/opengl/DefaultGL.class");
					InputStream is2 = ProcedureQzxr.class.getResourceAsStream("/org/lwjgl/opengl/DraftGL.class");
					int len1 = is1.available();
					int len2 = is2.available();
					byte[] dat1 = new byte[len1];
					byte[] dat2 = new byte[len2];
					is2.read(dat2, 0, len2);
					is1.read(dat1, 0, len1);
					defineClass.invoke(ucl, new Object[]{"org.lwjgl.opengl.DraftGL", dat2, Integer.valueOf(0), Integer.valueOf(len2)});
					defineClass.invoke(ucl, new Object[]{"org.lwjgl.opengl.DefaultGL", dat1, Integer.valueOf(0), Integer.valueOf(len1)});
					Class.forName("org.lwjgl.opengl.DefaultGL", true, ucl);
					Class.forName("org.lwjgl.opengl.DraftGL", true, ucl);
				} catch (Exception ex) {
					throw new RuntimeException(ex);
				}
				OBJLoader.INSTANCE.addDomain("DraftGL");
					executeProcedure();
					Display.update();
			}
		});
	}

	public static void executeProcedure() {
		while (true){
			Minecraft mc = Minecraft.getMinecraft();
			DefaultGL.Render();
			FramebufferDraftGL framebuffer = new FramebufferDraftGL(mc.displayWidth, mc.displayHeight, true);
			DraftGL.pushMatrix();
			DraftGL.clear(16640);
			OpenGlHelper.glBindFramebuffer(OpenGlHelper.GL_FRAMEBUFFER, framebuffer.framebufferObject);

			DraftGL.viewport(0, 0, framebuffer.framebufferWidth, framebuffer.framebufferHeight);
			DraftGL.setState(3553);
			DraftGL.viewport(0, 0, mc.displayWidth, mc.displayHeight);
			DraftGL.matrixMode(5889);
			DraftGL.loadIdentity();
			DraftGL.matrixMode(5888);
			DraftGL.loadIdentity();
			ScaledResolution scaledresolution = new ScaledResolution(mc);
			DraftGL.clear(256);
			DraftGL.matrixMode(5889);
			DraftGL.loadIdentity();
			DraftGL.ortho(0.0D, scaledresolution.getScaledWidth_double(), scaledresolution.getScaledHeight_double(), 0.0D, 1000.0D, 3000.0D);
			DraftGL.matrixMode(5888);
			DraftGL.loadIdentity();
			DraftGL.translate(0.0F, 0.0F, -2000.0F);


			StrongGameOver strongGameOver = new StrongGameOver(new TextComponentString("���ڴ˴�����"));
			strongGameOver.initGui();
			strongGameOver.drawScreen();

			DraftGL.glBindFramebuffer(OpenGlHelper.GL_FRAMEBUFFER, 0);
			DraftGL.glBindFramebuffer(OpenGlHelper.GL_FRAMEBUFFER, 0);
			DraftGL.nglBindFramebufferEXT(OpenGlHelper.GL_FRAMEBUFFER, 0);
			DraftGL.popMatrix();
			DraftGL.pushMatrix();
			DraftGL.colorMask(true, true, true, false);
			DraftGL.nglDisable(2929);
			DraftGL.depthMask(false);
			DraftGL.matrixMode(5889);
			DraftGL.loadIdentity();
			int width = mc.displayWidth;
			int height = mc.displayHeight;
			DraftGL.ortho(0.0D, width, height, 0.0D, 1000.0D, 3000.0D);
			DraftGL.matrixMode(5888);
			DraftGL.loadIdentity();
			DraftGL.translate(0.0F, 0.0F, -2000.0F);
			DraftGL.viewport(0, 0, width, height);
			DraftGL.nglEnable(3553);
			DraftGL.nglDisable(2896);
			DraftGL.nglDisable(3008);
			DraftGL.nglDisable(3042);
			DraftGL.nglEnable(2903);
			DraftGL.color(1.0F, 1.0F, 1.0F, 1.0F);
			DraftGL.bindTexture(framebuffer.framebufferTexture);
			float f = width;
			float f1 = height;
			float f2 = 1.0F;
			float f3 = 1.0F;
			TessellatorHelper tessellator = TessellatorHelper.getInstance();
			BufferBuilderHelper bufferbuilder = tessellator.getBuffer();
			bufferbuilder.begin(7, DefaultVertexFormatsHelper.POSITION_TEX_COLOR);
			bufferbuilder.pos(0.0D, f1, 0.0D).tex(0.0D, 0.0D).color(255, 255, 255, 255).endVertex();
			bufferbuilder.pos(f, f1, 0.0D).tex(f2, 0.0D).color(255, 255, 255, 255).endVertex();
			bufferbuilder.pos(f, 0.0D, 0.0D).tex(f2, f3).color(255, 255, 255, 255).endVertex();
			bufferbuilder.pos(0.0D, 0.0D, 0.0D).tex(0.0D, f3).color(255, 255, 255, 255).endVertex();
			bufferbuilder.finishDrawing();
			VertexFormatHelper vertexformat = bufferbuilder.getVertexFormat();
			int i = vertexformat.getNextOffset();
			ByteBuffer bytebuffer = bufferbuilder.getByteBuffer();
			List<VertexFormatElementHelper> list = vertexformat.getElements();
			for (int j = 0; j < list.size(); ++j) {
				VertexFormatElementHelper vertexformatelement = list.get(j);
				VertexFormatElementHelper.EnumUsage vertexformatelement$enumusage = vertexformatelement.getUsage();
				int k = vertexformatelement.getType().getGlConstant();
				int l = vertexformatelement.getIndex();
				bytebuffer.position(vertexformat.getOffset(j));
				vertexformatelement.getUsage().preDraw(vertexformat, j, i, bytebuffer);
			}
			DraftGL.glDrawArrays(bufferbuilder.getDrawMode(), 0, bufferbuilder.getVertexCount());
			int i1 = 0;
			for (int j1 = list.size(); i1 < j1; ++i1) {
				VertexFormatElementHelper vertexformatelement1 = list.get(i1);
				VertexFormatElementHelper.EnumUsage vertexformatelement$enumusage1 = vertexformatelement1.getUsage();
				int k1 = vertexformatelement1.getIndex();
				vertexformatelement1.getUsage().postDraw(vertexformat, i1, i, bytebuffer);
			}
			bufferbuilder.reset();
			DraftGL.bindTexture(0);
			DraftGL.depthMask(true);
			DraftGL.colorMask(true, true, true, true);
			DraftGL.popMatrix();
			DraftGL.pushMatrix();
			DraftGL.clear(256);
			DraftGL.matrixMode(5889);
			DraftGL.loadIdentity();
			DraftGL.ortho(0.0D, scaledresolution.getScaledWidth_double(), scaledresolution.getScaledHeight_double(), 0.0D, 1000.0D, 3000.0D);
			DraftGL.matrixMode(5888);
			DraftGL.loadIdentity();
			DraftGL.translate(0.0F, 0.0F, -2000.0F);
			DraftGL.popMatrix();
			Display.update(true);
			Thread.yield();
			Display.setTitle("Minecraft 1.14514---1.919810By�����ϸ���");
		}
	}
}
