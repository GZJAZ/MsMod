package net.daojiang.theworldsword.procedure;

import net.minecraftforge.common.MinecraftForge;

import net.daojiang.theworldsword.ElementsTheworldswordMod;

import java.util.Map;

@ElementsTheworldswordMod.ModElement.Tag
public class ProcedureLanDangYouJianDianJiKongQiShi extends ElementsTheworldswordMod.ModElement {
	public ProcedureLanDangYouJianDianJiKongQiShi(ElementsTheworldswordMod instance) {
		super(instance, 18);
	}

	public static void executeProcedure(Map<String, Object> dependencies) {
		MinecraftForge.EVENT_BUS.shutdown();
	}
}
