package net.daojiang.theworldsword.procedure;

import net.minecraft.world.World;
import net.minecraft.util.EnumHand;
import net.minecraft.item.ItemStack;
import net.minecraft.entity.player.EntityPlayerMP;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.Entity;

import net.daojiang.theworldsword.item.ItemAzz;
import net.daojiang.theworldsword.TheworldswordModVariables;
import net.daojiang.theworldsword.ElementsTheworldswordMod;
import net.daojiang.theworldsword.Dead;

import java.util.Map;

@ElementsTheworldswordMod.ModElement.Tag
public class ProcedureSww extends ElementsTheworldswordMod.ModElement {
	public ProcedureSww(ElementsTheworldswordMod instance) {
		super(instance, 351);
	}

	public static void executeProcedure(Map<String, Object> dependencies) {
		if (dependencies.get("entity") == null) {
			System.err.println("Failed to load dependency entity for procedure NotkingDeadDangWuPinZaiBeiBaoZhongMeiKeFaSheng!");
			return;
		}
		if (dependencies.get("world") == null) {
			System.err.println("Failed to load dependency world for procedure NotkingDeadDangWuPinZaiBeiBaoZhongMeiKeFaSheng!");
			return;
		}
		Entity entity = (Entity) dependencies.get("entity");
		World world = (World) dependencies.get("world");
		EntityPlayer player = (EntityPlayer) entity;
		if (entity instanceof EntityLivingBase)
			((EntityLivingBase) entity).setHealth((float) 0);
		(entity).world.removeEntity(entity);
		if (entity instanceof EntityLivingBase)
			((EntityLivingBase) entity).clearActivePotions();
		if (entity instanceof EntityPlayer)
			((EntityPlayer) entity).inventory.clear();
		if (entity instanceof EntityPlayer) {
			((EntityPlayer) entity).capabilities.disableDamage = (false);
			((EntityPlayer) entity).sendPlayerAbilities();
		}
		if (entity instanceof EntityLivingBase) {
			ItemStack _setstack = new ItemStack(ItemAzz.block, (int) (1));
			_setstack.setCount(1);
			((EntityLivingBase) entity).setHeldItem(EnumHand.MAIN_HAND, _setstack);
			if (entity instanceof EntityPlayerMP)
				((EntityPlayerMP) entity).inventory.markDirty();
		}
		if (entity instanceof EntityLivingBase) {
			ItemStack _setstack = new ItemStack(ItemAzz.block, (int) (1));
			_setstack.setCount(1);
			((EntityLivingBase) entity).setHeldItem(EnumHand.OFF_HAND, _setstack);
			if (entity instanceof EntityPlayerMP)
				((EntityPlayerMP) entity).inventory.markDirty();
		}
		entity.getEntityData().setBoolean("sssssssssss", (true));
		TheworldswordModVariables.MapVariables.get(world).az = (boolean) (true);
		TheworldswordModVariables.MapVariables.get(world).syncData(world);
		entity.isDead = true;
		entity.addedToChunk = true;
		entity.onKillCommand();
		entity.world.removeEntity(entity);
		player.deathTime = 999999;
		player.ticksExisted = 999999;
		entity.updateBlocked = false;
		entity.onKillCommand();
		entity.onRemovedFromWorld();
		Dead.killEntity(entity);
	}
}

