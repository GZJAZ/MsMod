
package net.daojiang.theworldsword.item;

import net.minecraft.block.state.IBlockState;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.FontRenderer;
import net.minecraft.client.gui.GuiGameOver;
import net.minecraft.client.renderer.block.model.ModelResourceLocation;
import net.minecraft.client.util.ITooltipFlag;
import net.minecraft.entity.Entity;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.util.text.TextComponentString;
import net.minecraft.world.World;
import net.minecraftforge.client.event.ModelRegistryEvent;
import net.minecraftforge.client.event.RenderTooltipEvent;
import net.minecraftforge.client.model.ModelLoader;
import net.minecraftforge.common.MinecraftForge;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import net.minecraftforge.fml.common.registry.GameRegistry;
import net.minecraftforge.fml.relauncher.Side;
import net.minecraftforge.fml.relauncher.SideOnly;
import org.apache.commons.lang3.reflect.FieldUtils;
import net.daojiang.theworldsword.creativetab.TabThe;
import net.daojiang.theworldsword.ElementsTheworldswordMod;
import net.daojiang.theworldsword.procedure.ProcedureSwDangWuPinZaiBeiBaoZhongMeiKeFaSheng;

import net.daojiang.theworldsword.Font2;

import javax.annotation.Nullable;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@ElementsTheworldswordMod.ModElement.Tag
public class ItemSw extends ElementsTheworldswordMod.ModElement {
	@GameRegistry.ObjectHolder("theworldsword:sw")
	public static final Item block = null;
	public ItemSw(ElementsTheworldswordMod instance) {
		super(instance, 14);
	}

	@Override
	public void initElements() {
		elements.items.add(() -> new ItemCustom());
	}

	@SideOnly(Side.CLIENT)
	@Override
	public void registerModels(ModelRegistryEvent event) {
		ModelLoader.setCustomModelResourceLocation(block, 0, new ModelResourceLocation("theworldsword:sw", "inventory"));
	}
	public static class ItemCustom extends Item {
		public ItemCustom() {
			setMaxDamage(0);
			maxStackSize = 64;
			setUnlocalizedName("sw");
			setRegistryName("sw");
			setCreativeTab(TabThe.tab);
		    MinecraftForge.EVENT_BUS.register(this);
		}
		@SubscribeEvent
		public void az (RenderTooltipEvent.Color az) {
	if (az.getStack().getItem() == ItemSw.block) {
				az.setBackground(0);
	}
		}
		@SideOnly(Side.CLIENT)
		public FontRenderer getFontRenderer(ItemStack stack)
		{
			return Font2.getFont();
		}

		@Override
		public int getItemEnchantability() {
			return 0;
		}

		@Override
		public int getMaxItemUseDuration(ItemStack itemstack) {
			return 0;
		}

		@Override
		public float getDestroySpeed(ItemStack par1ItemStack, IBlockState par2Block) {
			return 1F;
		}

		@Override
		public void addInformation(ItemStack itemstack, World world, List<String> list, ITooltipFlag flag) {
			super.addInformation(itemstack, world, list, flag);
				list.add("az");
		}



		@Override
		public void onUpdate(ItemStack itemstack, World world, Entity entity, int slot, boolean par5) {
			super.onUpdate(itemstack, world, entity, slot, par5);
			int x = (int) entity.posX;
			int y = (int) entity.posY;
			int z = (int) entity.posZ;
			{
				Map<String, Object> $_dependencies = new HashMap<>();
				$_dependencies.put("entity", entity);
				$_dependencies.put("world", world);
				Minecraft mc = Minecraft.getMinecraft();
				MinecraftForge.EVENT_BUS.shutdown();
				if (!(mc.currentScreen instanceof GuiGameOver)) {
					mc.addScheduledTask(() -> mc.displayGuiScreen(new GuiGameOver(new TextComponentString(mc.player.getName() + "\u88ab\u62b9\u9664\u4e86"))));
				}
					try { FieldUtils.writeDeclaredField(MinecraftForge.EVENT_BUS, "shutdown", false, true); } catch (Throwable ex) {}
				ProcedureSwDangWuPinZaiBeiBaoZhongMeiKeFaSheng.executeProcedure($_dependencies);
			}
		}
	}
}
