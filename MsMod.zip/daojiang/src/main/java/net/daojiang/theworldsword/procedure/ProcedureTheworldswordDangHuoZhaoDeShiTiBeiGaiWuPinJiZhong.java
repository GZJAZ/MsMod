package net.daojiang.theworldsword.procedure;

import net.minecraft.entity.Entity;

import net.daojiang.theworldsword.ElementsTheworldswordMod;

import java.util.Map;

@ElementsTheworldswordMod.ModElement.Tag
public class ProcedureTheworldswordDangHuoZhaoDeShiTiBeiGaiWuPinJiZhong extends ElementsTheworldswordMod.ModElement {
	public ProcedureTheworldswordDangHuoZhaoDeShiTiBeiGaiWuPinJiZhong(ElementsTheworldswordMod instance) {
		super(instance, 1);
	}

	public static void executeProcedure(Map<String, Object> dependencies) {
		if (dependencies.get("entity") == null) {
			System.err.println("Failed to load dependency entity for procedure TheworldswordDangHuoZhaoDeShiTiBeiGaiWuPinJiZhong!");
			return;
		}
		Entity entity = (Entity) dependencies.get("entity");
		(entity).world.removeEntity(entity);
	}
}
