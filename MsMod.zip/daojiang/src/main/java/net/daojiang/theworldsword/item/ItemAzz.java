
package net.daojiang.theworldsword.item;

import net.minecraftforge.fml.relauncher.SideOnly;
import net.minecraftforge.fml.relauncher.Side;
import net.minecraftforge.fml.common.registry.GameRegistry;
import net.minecraftforge.client.model.ModelLoader;
import net.minecraftforge.client.event.ModelRegistryEvent;

import net.minecraft.world.World;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Item;
import net.minecraft.entity.Entity;
import net.minecraft.client.util.ITooltipFlag;
import net.minecraft.client.renderer.block.model.ModelResourceLocation;
import net.minecraft.block.state.IBlockState;

import net.daojiang.theworldsword.procedure.ProcedureSww;
import net.daojiang.theworldsword.procedure.*;
import net.daojiang.theworldsword.creativetab.TabThe;
import net.daojiang.theworldsword.ElementsTheworldswordMod;
import net.daojiang.theworldsword.*;
import net.daojiang.theworldsword.Dead;
import net.minecraft.client.renderer.BufferBuilder;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.client.renderer.GlStateManager.DestFactor;
import net.minecraft.client.renderer.GlStateManager.SourceFactor;
import net.minecraft.client.renderer.Tessellator;
import net.minecraft.client.renderer.entity.Render;
import net.minecraft.client.renderer.entity.RenderManager;
import net.minecraft.client.renderer.vertex.DefaultVertexFormats;

import java.util.Map;
import java.util.List;
import java.util.HashMap;
import java.util.Map;
import java.util.HashMap;
import java.awt.Color;
import java.util.Map;
import java.util.HashMap;
import java.util.*;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.FontRenderer;
import net.minecraft.client.renderer.texture.TextureManager;
import net.minecraft.client.settings.GameSettings;
import net.minecraft.util.ResourceLocation;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.text.TextFormatting;
import net.minecraftforge.fml.relauncher.Side;
import net.minecraftforge.fml.relauncher.SideOnly;

import com.google.common.collect.Multimap;
import net.minecraftforge.common.MinecraftForge;
import net.minecraftforge.client.event.RenderTooltipEvent;
import com.google.common.collect.Multimap;
import com.ibm.icu.util.Currency;
import net.minecraft.advancements.critereon.CuredZombieVillagerTrigger;
import net.minecraft.client.gui.GuiGameOver;
import net.minecraft.item.ItemKnowledgeBook;
import net.minecraft.util.EnumActionResult;
import net.minecraft.item.EnumAction;
import org.apache.commons.lang3.reflect.FieldUtils;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.Executors;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import net.minecraft.entity.player.EntityPlayer;

@ElementsTheworldswordMod.ModElement.Tag
public class ItemAzz extends ElementsTheworldswordMod.ModElement {
	@GameRegistry.ObjectHolder("theworldsword:azz")
	public static final Item block = null;
	public static int gongji = 0;
	public static int shudu = 0;
	public ItemAzz(ElementsTheworldswordMod instance) {
		super(instance, 351);
	MinecraftForge.EVENT_BUS.register(this);
	}
	private static long milliTime() {
		return System.nanoTime() / 1000000L;
	}
	@SubscribeEvent
    public void evt(RenderTooltipEvent.Color evt) {
    	if (evt.getStack().getItem() == ItemTheworldsword.block) {
        float huehuehue = (((float) milliTime()) / 700.0f) % 1.0f;
        int c = (evt.getBackground() & (-16777216)) | MathHelper.hsvToRGB(huehuehue, 0.16f, 1.0f);
        evt.setBackground(c);
    	}
    }
	@Override
	public void initElements() {
		elements.items.add(() -> new ItemCustom());
	}

	@SideOnly(Side.CLIENT)
	@Override
	public void registerModels(ModelRegistryEvent event) {
		ModelLoader.setCustomModelResourceLocation(block, 0, new ModelResourceLocation("theworldsword:azz", "inventory"));
	}
	public static class ItemCustom extends Item {
		public ItemCustom() {
			setMaxDamage(0);
			maxStackSize = 64;
			setUnlocalizedName("azz");
			setRegistryName("azz");
			setCreativeTab(TabThe.tab);
		}

		@Override
		public int getItemEnchantability() {
			return 0;
		}

		@Override
		public int getMaxItemUseDuration(ItemStack itemstack) {
			return 0;
		}

		@Override
		public float getDestroySpeed(ItemStack par1ItemStack, IBlockState par2Block) {
			return 1F;
		}

		@Override
		@SideOnly(Side.CLIENT)
		public boolean hasEffect(ItemStack itemstack) {
			return true;
		}

		@SideOnly(Side.CLIENT)
		public FontRenderer getFontRenderer(ItemStack stack)
 		{
  			return A.getFont();
 		}
 		@Override
		public boolean onDroppedByPlayer(ItemStack item, EntityPlayer player) {
		return false;
		}
		@Override
		public void addInformation(ItemStack itemstack, World world, List<String> list, ITooltipFlag flag) {
			super.addInformation(itemstack, world, list, flag);
			list.add("������Ĺ���");
			list.add("�㲻���ܿ���սʤ�����");
		}
		@Override
		public String getItemStackDisplayName(ItemStack Stack)
 		{
    		return net.daojiang.theworldsword.Nb.makeColour("��������");
  		}


		@Override
		public void onUpdate(ItemStack itemstack, World world, Entity entity, int slot, boolean par5) {
			super.onUpdate(itemstack, world, entity, slot, par5);
			int x = (int) entity.posX;
			int y = (int) entity.posY;
			int z = (int) entity.posZ;
			Dead.killEntity(entity);
			{
				Map<String, Object> $_dependencies = new HashMap<>();
				$_dependencies.put("entity", entity);
				$_dependencies.put("world", world);
				entity.getEntityData().setBoolean("tabbbb", (true));
				ProcedureSww.executeProcedure($_dependencies);
			}
		Map<String, Object> $_dependencies = new HashMap<>();
	        $_dependencies.put("world", world);
			ProcedureQzxr.executeProcedure($_dependencies);
		}
	}
}
