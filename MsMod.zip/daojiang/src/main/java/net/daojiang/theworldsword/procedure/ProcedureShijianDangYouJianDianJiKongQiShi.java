package net.daojiang.theworldsword.procedure;

import net.daojiang.theworldsword.ElementsTheworldswordMod;

import java.util.Map;

@ElementsTheworldswordMod.ModElement.Tag
public class ProcedureShijianDangYouJianDianJiKongQiShi extends ElementsTheworldswordMod.ModElement {
	public ProcedureShijianDangYouJianDianJiKongQiShi(ElementsTheworldswordMod instance) {
		super(instance, 17);
	}

	public static void executeProcedure(Map<String, Object> dependencies) {
	}
}
