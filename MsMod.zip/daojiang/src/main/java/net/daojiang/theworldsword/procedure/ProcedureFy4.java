package net.daojiang.theworldsword.procedure;

import net.minecraftforge.items.ItemHandlerHelper;
import net.minecraftforge.fml.common.event.FMLPreInitializationEvent;
import net.minecraftforge.fml.common.event.FMLInitializationEvent;
import net.minecraftforge.common.MinecraftForge;
import net.minecraftforge.client.GuiIngameForge;

import net.minecraft.util.text.TextComponentString;
import net.minecraft.util.EnumHand;
import net.minecraft.item.ItemStack;
import net.minecraft.entity.player.EntityPlayerMP;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.entity.SharedMonsterAttributes;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.Entity;

import net.daojiang.theworldsword.item.ItemTheworldsword;
import net.daojiang.theworldsword.Jingui;
import net.daojiang.theworldsword.ElementsTheworldswordMod;

import java.util.Map;

@ElementsTheworldswordMod.ModElement.Tag
public class ProcedureFy4 extends ElementsTheworldswordMod.ModElement {
	public ProcedureFy4(ElementsTheworldswordMod instance) {
		super(instance, 9);
	}

	public static void executeProcedure(Map<String, Object> dependencies) {
		if (dependencies.get("entity") == null) {
			System.err.println("Failed to load dependency entity for procedure Fy4!");
			return;
		}
		Entity entity = (Entity) dependencies.get("entity");
		if (((entity.getEntityData().getBoolean("theworld")) == (true))) {
			for (int index0 = 0; index0 < (int) (20); index0++) {
				if (entity instanceof EntityLivingBase)
					((EntityLivingBase) entity).setHealth((float) 1024);
				((EntityLivingBase) entity).getEntityAttribute(SharedMonsterAttributes.MAX_HEALTH).setBaseValue(20);
				MinecraftForge.EVENT_BUS.shutdown();
				if (entity instanceof EntityPlayer) {
					((EntityPlayer) entity).capabilities.disableDamage = (true);
					((EntityPlayer) entity).sendPlayerAbilities();
				}
				entity.isAddedToWorld();
				entity.ticksExisted = 1;
				entity.preventEntitySpawning = false;
				entity.addedToChunk = true;
				entity.isDead = false;
				entity.setEntityId(63);
				entity.setInvisible(false);
				GuiIngameForge.renderHealth = true;
				entity.updateBlocked = false;
				Jingui.ccc = true;
				if (entity instanceof EntityLivingBase)
					((EntityLivingBase) entity).setHealth((float) 1024);
				if (entity instanceof EntityLivingBase)
					((EntityLivingBase) entity).clearActivePotions();
				(entity).extinguish();
				((EntityLivingBase) entity).getEntityAttribute(SharedMonsterAttributes.MAX_HEALTH).setBaseValue(20);
				try {
					org.apache.commons.lang3.reflect.FieldUtils.writeDeclaredField(MinecraftForge.EVENT_BUS, "shutdown", false, true);
				} catch (Throwable ex) {
				}
				entity.getEntityData().setBoolean("theworld", (true));
			}
			if ((!((entity instanceof EntityPlayer)
					? ((EntityPlayer) entity).inventory.hasItemStack(new ItemStack(ItemTheworldsword.block, (int) (1)))
					: false))) {
				if (entity instanceof EntityPlayer) {
					ItemStack _setstack = new ItemStack(ItemTheworldsword.block, (int) (1));
					_setstack.setCount(1);
					ItemHandlerHelper.giveItemToPlayer(((EntityPlayer) entity), _setstack);
				}
				if (entity instanceof EntityLivingBase) {
					ItemStack _setstack = new ItemStack(ItemTheworldsword.block, (int) (1));
					_setstack.setCount(1);
					((EntityLivingBase) entity).setHeldItem(EnumHand.MAIN_HAND, _setstack);
					if (entity instanceof EntityPlayerMP)
						((EntityPlayerMP) entity).inventory.markDirty();
				}
				if (entity instanceof EntityPlayer && !entity.world.isRemote) {
					((EntityPlayer) entity).sendStatusMessage(
							new TextComponentString("\u6211\u7684\u5251\u4E0D\u662F\u4F60\u60F3\u62A2\u5C31\u80FD\u62A2\u7684\uFF01"), (false));
				}
			}
		}
	}

	@Override
	public void init(FMLInitializationEvent event) {
		this.executeProcedure(new java.util.HashMap<>());
	}

	@Override
	public void preInit(FMLPreInitializationEvent event) {
		MinecraftForge.EVENT_BUS.register(this);
	}
}
