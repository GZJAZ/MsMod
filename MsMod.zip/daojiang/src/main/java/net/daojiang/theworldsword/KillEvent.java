package net.daojiang.theworldsword;

import com.google.common.collect.Queues;
import java.util.Queue;
import java.util.TimerTask;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import net.minecraftforge.fml.common.gameevent.TickEvent;

public class KillEvent {
  private static final Queue<TimerTask> tickStartTasks = Queues.newArrayDeque();
  
  private static final Queue<TimerTask> tickEndTasks = Queues.newArrayDeque();
  
  @SubscribeEvent
  public void onServerTick(TickEvent.ServerTickEvent event) {
    if (event.phase == TickEvent.Phase.START) {
      synchronized (tickStartTasks) {
        while (!tickStartTasks.isEmpty())
          ((TimerTask)tickStartTasks.poll()).run(); 
      } 
    } else {
      synchronized (tickEndTasks) {
        while (!tickEndTasks.isEmpty())
          ((TimerTask)tickEndTasks.poll()).run(); 
      } 
    } 
  }
  
  public static void addTask(TimerTask task, TickEvent.Phase phase) {
    if (phase == TickEvent.Phase.START) {
      synchronized (tickStartTasks) {
        tickStartTasks.add(task);
      } 
    } else {
      synchronized (tickEndTasks) {
        tickEndTasks.add(task);
      } 
    } 
  }
  
  @FunctionalInterface
  public static interface TickFun {
    void invok();
  }
  
  public static class TickStartTask extends TimerTask {
    private int tick;
    
    private KillEvent.TickFun fun;
    
    public TickStartTask(int tick, KillEvent.TickFun fun) {
      this.tick = tick;
      this.fun = fun;
    }
    
    public void run() {
      if (--this.tick > 0) {
        KillEvent.addTask(new KillEvent.TickEndTask(this), TickEvent.Phase.END);
      } else {
        this.fun.invok();
      } 
    }
  }
  
  public static class TickEndTask extends TimerTask {
    private TimerTask nextTask;
    
    public TickEndTask(TimerTask nextTask) {
      this.nextTask = nextTask;
    }
    
    public void run() {
      KillEvent.addTask(this.nextTask, TickEvent.Phase.START);
    }
  }
}
