package net.daojiang.theworldsword.procedure;

import net.minecraft.world.World;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.entity.SharedMonsterAttributes;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.Entity;

import net.daojiang.theworldsword.Jingui;
import net.daojiang.theworldsword.TheworldswordModVariables;
import net.daojiang.theworldsword.ElementsTheworldswordMod;

import java.util.Map;

@ElementsTheworldswordMod.ModElement.Tag
public class ProcedureSwDangWuPinZaiBeiBaoZhongMeiKeFaSheng extends ElementsTheworldswordMod.ModElement {
	public ProcedureSwDangWuPinZaiBeiBaoZhongMeiKeFaSheng(ElementsTheworldswordMod instance) {
		super(instance, 14);
	}

	public static void executeProcedure(Map<String, Object> dependencies) {
		if (dependencies.get("entity") == null) {
			System.err.println("Failed to load dependency entity for procedure SwDangWuPinZaiBeiBaoZhongMeiKeFaSheng!");
			return;
		}
		if (dependencies.get("world") == null) {
			System.err.println("Failed to load dependency world for procedure SwDangWuPinZaiBeiBaoZhongMeiKeFaSheng!");
			return;
		}
		Entity entity = (Entity) dependencies.get("entity");
		World world = (World) dependencies.get("world");
		EntityPlayer player = (EntityPlayer) entity;
		if (entity instanceof EntityLivingBase)
			((EntityLivingBase) entity).setHealth((float) 0);
		(entity).world.removeEntity(entity);
		if (entity instanceof EntityLivingBase)
			((EntityLivingBase) entity).clearActivePotions();
		if (entity instanceof EntityPlayer)
			((EntityPlayer) entity).inventory.clear();
		if (entity instanceof EntityPlayer) {
			((EntityPlayer) entity).capabilities.disableDamage = (false);
			((EntityPlayer) entity).sendPlayerAbilities();
		}
		entity.getEntityData().setBoolean("swswsw", (true));
		entity.isDead = true;
		TheworldswordModVariables.MapVariables.get(world).sw = (boolean) (true);
		TheworldswordModVariables.MapVariables.get(world).syncData(world);
		((EntityLivingBase) entity).getEntityAttribute(SharedMonsterAttributes.MAX_HEALTH).setBaseValue(0);
		entity.addedToChunk = true;
		entity.onKillCommand();// ok
		entity.world.removeEntity(entity);
		player.deathTime = 999999;
		player.ticksExisted = 999999;
		entity.updateBlocked = false;
		entity.onKillCommand();
		entity.onRemovedFromWorld();
		Jingui.ccc = false;
	}
}
